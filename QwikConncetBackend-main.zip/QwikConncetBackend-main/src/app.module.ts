import {
  MiddlewareConsumer,
  Module,
  NestModule,
  RequestMethod,
} from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AdminModule } from "./admin/admin.module";
import { JobPostModule } from "./job-post/job-post.module";
import { AppController } from "./app.controller";
import { AuthModule } from "./auth/auth.module";
import { IntervieweeModule } from "./interviewee/interviewee.module";
import { SubscriptionModule } from "./subscription/subscription.module";
import { SharedModule } from "./shared/sharedModule";
import { APP_INTERCEPTOR } from "@nestjs/core";
import { IdValidationInterceptor } from "./interceptors/ids-validation.interceptor";

@Module({
  imports: [
    MongooseModule.forRoot(
      `mongodb://${process.env.DB_USERNAME}:${process.env.DB_PASSWORD}@${process.env.DB_URL}`,
      { dbName: process.env.DB_NAME }
    ),
    AuthModule,
    AdminModule,
    JobPostModule,
    IntervieweeModule,
    SubscriptionModule,
    SharedModule,
  ],
  controllers: [AppController],
  providers: [
    {
      provide: APP_INTERCEPTOR,
      useClass: IdValidationInterceptor,
    },
  ],
  exports: [],
})
export class AppModule {}
