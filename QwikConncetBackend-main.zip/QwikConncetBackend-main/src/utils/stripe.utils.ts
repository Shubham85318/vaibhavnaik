import { stripeConfig } from "src/config";
import { Stripe } from "stripe";

const stripe = new Stripe(stripeConfig.secretKey);
