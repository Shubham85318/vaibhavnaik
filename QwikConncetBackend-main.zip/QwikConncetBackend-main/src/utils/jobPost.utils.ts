import * as fs from "fs";
import { v4 as uuidv4 } from "uuid";

export const readTxtFile = async (filePath: string): Promise<string> => {
  return new Promise<string>((resolve, reject) => {
    fs.readFile(filePath, "utf8", (err, data) => {
      if (err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
};

export const generateUUID = (): string => {
  return uuidv4();
};

export const getRandomElementsFromArray = async (arr, numElements) => {
  if (numElements >= arr.length) {
    return arr; // Return the original array if numElements is greater or equal to its length.
  }

  const shuffledArray = arr.slice(); // Create a copy of the original array.

  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
    if (i === numElements) {
      break; // Stop shuffling once numElements have been selected.
    }
  }

  return shuffledArray.slice(0, numElements); // Return the first numElements from the shuffled array.
};

export const getRandomQuestions = (toSelect, questions) => {
  if (toSelect >= questions.length) {
    return shuffleArray(questions);
  }
  const copy = [...questions];
  const shuffled = shuffleArray(copy);
  return shuffled.slice(0, toSelect);
};

// Function to shuffle an array randomly.
const shuffleArray = (array) => {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
};

export const filterQuestions = (questions) => {
  return questions.reduce(
    (result, question) => {
      if (question.isMandatory) {
        result.mandatoryQuestions.push(question);
      } else {
        result.rest.push(question);
      }
      return result;
    },
    { mandatoryQuestions: [], rest: [] }
  );
};
