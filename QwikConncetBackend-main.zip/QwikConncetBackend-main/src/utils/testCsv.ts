// const fs = require('fs');

// // Sample data to write to CSV
// const csvData = [
//   ['Name', 'Age', 'Location'],
//   ['John', '25', 'New York'],
//   ['Jane', '30', 'Los Angeles'],
//   ['Michael', '22', 'Chicago']
// ];

// // CSV file path
// const csvFilePath = 'sample.csv';

// // Convert data to CSV format
// const csvContent = csvData.map(row => row.join(',')).join('\n');

// // Write CSV content to file
// fs.writeFile(csvFilePath, csvContent, (err) => {
//   if (err) {
//     console.error('Error writing CSV file:', err);
//   } else {
//     console.log('CSV file has been created successfully!');
//   }
// });
const now = new Date();
const exp = new Date();
exp.setDate(exp.getDate() + 5);
console.log(exp.getTime() > now.getTime());
