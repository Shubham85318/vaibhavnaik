export const createPrivateLinks = (
  adminId: string,
  jobId: string,
  data: any[]
): string[] => {
  if (!Array.isArray(data)) {
    return [];
  }

  const privateLinks = data.map((entry) => {
    const email = entry.Email; // Assuming the email field is named "Email"
    return `https://qwick-connect.io/${adminId}/${jobId}/pvt?email=${email}`;
  });

  return privateLinks;
};
