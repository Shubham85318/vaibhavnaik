export const getRandomAvatar = (avatars): Promise<any> => {
  if (avatars.length === 0) {
    return null; // Return null if the array is empty
  }
  const randomIndex = Math.floor(Math.random() * avatars.length);
  // const {key} = avatars[randomIndex];
  return avatars[randomIndex];
};
