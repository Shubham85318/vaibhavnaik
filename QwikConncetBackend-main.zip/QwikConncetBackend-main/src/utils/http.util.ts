import axios, { AxiosRequestConfig, AxiosResponse } from "axios";
import * as _ from "lodash";
import { Logger as logger } from "@nestjs/common";

const validateResponse = async (response: AxiosResponse<any, any>) => {
  // Implement your validation logic here, e.g., check for specific status codes
  if (response.status !== 200) {
    throw new Error(`Invalid response status: ${response.status}`);
  }
};

const processErrorResponse = async (url: string, error: any) => {
  const response = _.get(error, "response");
  await validateResponse(response);
  logger.error(`Error in GET request: ${url}`, response);
};

export const get = async (
  url: string,
  config?: AxiosRequestConfig
): Promise<AxiosResponse<any, any>> => {
  try {
    const response = await axios.get(url, config);
    await validateResponse(response);
    return response;
  } catch (error) {
    if (_.has(error, "response")) {
      await processErrorResponse(url, error);
    } else {
      logger.error(`Error in GET request: ${url}`, error);
    }
    throw error;
  }
};

export const post = async (
  url: string,
  data?: any,
  config?: AxiosRequestConfig
): Promise<AxiosResponse<any, any>> => {
  try {
    const response = await axios.post(url, data, config);
    await validateResponse(response);
    return response;
  } catch (error) {
    if (_.has(error, "response")) {
      await processErrorResponse(url, error);
    } else {
      logger.error(`Error in POST request: ${url}`, error);
    }
    throw error;
  }
};
