import * as ffmpeg from "fluent-ffmpeg";

export const getVideoDurationInMinutes = async (
  video: Express.Multer.File
): Promise<string> => {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(video.path, (err, metadata) => {
      if (err) {
        console.error("Error:", err);
        reject(err);
        return;
      }

      const durationInSeconds = metadata.format.duration;
      const durationInMinutes = durationInSeconds / 60; // Convert seconds to minutes
      resolve(durationInMinutes.toString());
    });
  });
};
