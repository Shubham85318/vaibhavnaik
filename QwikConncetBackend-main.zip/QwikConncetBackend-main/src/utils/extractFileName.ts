export const extractFilenameFromKey = (key) => {
  // Split the key by '/'
  const parts = key.split("/");

  // Get the last part (filename)
  const filename = parts[parts.length - 1];

  return filename;
};
