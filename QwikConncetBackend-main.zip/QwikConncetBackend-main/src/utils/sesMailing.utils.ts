import * as aws from "aws-sdk";
import { config } from "dotenv";
config({ override: true });

const SES_CONFIG = {
  accessKeyId: process.env.SES_AWS_ACCESS_KEY,
  secretAccessKey: process.env.SES_AWS_SECRET_ACCESS_KEY,
  region: process.env.SES_REGION,
};

const AWS_SES = new aws.SES(SES_CONFIG);

//sending bulk by extracting an user from csv file
export const sendBulkMail = async (users, templateName) => {
  const user1 = [
    { name: "arpit", otp: "78723873", email: "arpitsingh2967@gmail.com" },
    { name: "avinash", otp: "89898", email: "arpitsingh9892@gmail.com" },
  ];

  let destinations = [];

  for (const user of users) {
    destinations.push({
      Destination: {
        ToAddresses: [user.email],
      },
      ReplacementTemplateData: JSON.stringify({
        name: user.name, // This will provide the value for username in template
        otp: user.otp, // This will provide the value for email in template
      }),
    });
  }

  const params = {
    Source: process.env.AWS_SES_SENDER, // sender email
    Template: templateName, // Template name we have created
    Destinations: destinations,
    DefaultTemplateData: JSON.stringify({
      username: "", // default value for username
      email: "", // default value for email
    }),
  };
  try {
    const sendPromise = await AWS_SES.sendBulkTemplatedEmail(params).promise();
    return sendPromise;
  } catch (err) {
    console.log(err);
  }
};

export const sendEmail = async (receipientEmail, name) => {
  let params = {
    Source: process.env.AWS_SES_SENDER,
    Destination: {
      ToAddresses: [receipientEmail],
    },
    ReplyToAddresses: [],
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: "",
          // Pass dynamic data using TemplateData
          //   TemplateData: JSON.stringify(dynamicData),
        },
        Text: {
          Charset: "UTF-8",
          Data: "sab complete krna h aaj sir ka call aaya tha",
        },
      },
      Subject: {
        Charset: "UTF-8",
        Data: `Hello, ${name}!`,
      },
    },
  };

  try {
    const res = await AWS_SES.sendEmail(params).promise();
    console.log("Email Has Been Sent", res);
  } catch (err) {
    console.log(err);
  }
};

export const sendTemplate = async (receipientEmail) => {
  // const a = await AWS_SES.createTemplate(template).promise();
  var params: any = {
    Destination: {
      /* required */
      CcAddresses: [
        // 'EMAIL_ADDRESS',
        /* more CC email addresses */
      ],
      ToAddresses: [
        receipientEmail,
        /* more To email addresses */
      ],
    },
    Source: process.env.AWS_SES_SENDER /* required */,
    Template: "QwikConnectOtpTemplate1" /* required */,
    TemplateData: '{ "name":"Arpit", "otp": "878787" }' /* required */,
    ReplyToAddresses: [
      // 'EMAIL_ADDRESS'
    ],
  };

  try {
    const sendPromise = await AWS_SES.sendTemplatedEmail(params).promise();
    console.log("Email Has Been Sent", sendPromise);
  } catch (err) {
    console.log(err);
  }
};

export const createTemplate = async () => {
  let params: any = {
    Template: {
      TemplateName: "QwikConnectOtpTemplate1",
      SubjectPart: "Dear, {{name}}!",
      HtmlPart:
        "<h1>Hello {{name}},</h1><p>{{otp}} is your OTP for QwickConnect registration. OTP is confidential and valid for 10 minutes. For security reasons, DO NOT share this OTP with anyone.</p>",
      // "TextPart": "Dear {{name}},\r\nYour favorite animal is {{favoriteanimal}}."
    },
  };
  try {
    const t = await AWS_SES.createTemplate(params).promise();
    console.log(t);
    return "template created successuflly";
  } catch (err) {
    throw err;
  }
};

export const deleteTemplate = async (templateName) => {
  const params = {
    TemplateName: templateName,
  };

  try {
    const result = await AWS_SES.deleteTemplate(params).promise();
    console.log(`Template ${templateName} deleted successfully:`, result);
    return;
  } catch (error) {
    console.error(`Error deleting template ${templateName}:`, error);
    throw error;
  }
};

// let params = {
//   Destinations: [
//     /* required */
//     {
//       Destination: {
//         /* required */
//         CcAddresses: [
//           // 'EMAIL_ADDRESS',
//           /* more items */
//         ],
//         ToAddresses: [
//           "arpitsingh2967@gmail.com",
//           // 'avinash.wagh@ayssoftwaresolution.com',
//           // 'hrushikeshvagga7@gmail.com',
//           "arpitsingh9892@gmail.com",
//           /* more items */
//         ],
//       },
//       ReplacementTags: [
//         { Name: "name", Value: "878787" },
//         { Name: "avinash", Value: "22222" },
//       ],
//       ReplacementTemplateData:
//         '{ "name":"arpit", "otp": "878787" }, {"name":"avinash", "otp": "22222"}',
//     },
//   ],
//   Source: process.env.AWS_SES_SENDER /* required */,
//   Template: "QwikConnectOtpTemplate1" /* required */,
//   DefaultTemplateData:'',
//   ReplyToAddresses: [
//     // 'EMAIL_ADDRESS'
//   ],
// };
