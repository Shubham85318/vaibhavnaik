import * as crypto from "crypto";

const algorithm = "aes-256-cbc";
const secret = "qwik-connect";

export function encrypt(data: any): string {
  // Convert the JSON object to a string
  const jsonString = JSON.stringify(data);
  const cipher = crypto.createCipher(algorithm, secret);
  let encrypted = cipher.update(jsonString, "utf8", "hex");
  encrypted += cipher.final("hex");
  return encrypted;
}

export function decrypt(encrypted: any): any {
  const decipher = crypto.createDecipher(algorithm, secret);
  let decrypted = decipher.update(encrypted, "hex", "utf8");
  decrypted += decipher.final("utf8");

  // Parse the decrypted string back to a JSON object
  return JSON.parse(decrypted);
}
