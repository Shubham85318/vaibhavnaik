import * as fastcsv from "fast-csv";

export const readCsvFile = async (csvData: string): Promise<any[]> => {
  return new Promise<any[]>((resolve, reject) => {
    const data: any[] = [];

    fastcsv
      .parseString(csvData, { headers: true })
      .on("data", (row) => {
        data.push(row);
      })
      .on("end", () => {
        resolve(data);
      })
      .on("error", (error) => {
        reject(error);
      });
  });
};
