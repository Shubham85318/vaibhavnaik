import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsString } from "class-validator";

export class VerifyOtpDto {
  @IsEmail()
  @ApiProperty({
    type: String,
    required: true,
    description: "User Email Address",
  })
  email: string;

  @IsString()
  @ApiProperty({ type: String, required: true, description: "Otp Received" })
  otp: string;

  @IsString()
  @ApiProperty({ type: String, required: true, description: "Otp Task Type" })
  task: string;
}
