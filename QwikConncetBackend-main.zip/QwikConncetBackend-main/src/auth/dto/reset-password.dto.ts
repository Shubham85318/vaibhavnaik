import { ApiProperty } from "@nestjs/swagger";
import { IsString } from "class-validator";

export class ResetPasswordDto {
  @IsString()
  @ApiProperty({
    name: "email",
    description: "Email address",
    required: true,
    type: String,
  })
  email: string;

  @IsString()
  @ApiProperty({
    name: "password",
    description: "Password",
    required: true,
    type: String,
  })
  password: string;
}
