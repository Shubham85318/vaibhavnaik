import { Logger, Module } from "@nestjs/common";
import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.service";
import { MongooseModule } from "@nestjs/mongoose";
import { OtpMap, OtpMapSchema } from "./schemas/otp.schema"; // Import OtpMap and OtpMapSchema
import { IntervieweeModule } from "src/interviewee/interviewee.module";

@Module({
  imports: [
    MongooseModule.forFeature([{ name: OtpMap.name, schema: OtpMapSchema }]),
    IntervieweeModule,
  ],
  controllers: [AuthController],
  providers: [AuthService, Logger],
  exports: [],
})
export class AuthModule {}
