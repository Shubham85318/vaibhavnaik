import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
} from "@nestjs/common";
import { Auth0Config, BaseServiceUrl } from "../config";
import axios from "axios";
import { OtpMap, OtpMapDocument } from "./schemas/otp.schema";
import { Model } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { generateOtp } from "src/utils/otp-generator";

import * as fs from "fs";
import * as http from "../utils/http.util";
import { OtpTask } from "./enum/otp-task.enum";
import { MailService } from "src/shared/mail.service";
const moment = require("moment");
// import { sendEmail } from "src/utils/sesMailing.utils"

@Injectable()
export class AuthService {
  private readonly clientId: string = Auth0Config.clientId;
  private readonly clientSecret: string = Auth0Config.clientSecret;
  private readonly audience: string = Auth0Config.audience;
  private readonly issuer: string = Auth0Config.issuer;
  constructor(
    @InjectModel(OtpMap.name)
    private readonly otpMapRepo: Model<OtpMapDocument>,
    private readonly logger: Logger,
    private readonly mailService: MailService
  ) {}

  async login(email: string, password: string) {
    try {
      // const data = {
      //   grant_type: "password",
      //   username: email,
      //   password: password,
      //   audience: this.audience,
      //   scope: scope,
      //   client_id: this.clientId,
      //   client_secret: this.clientSecret,
      // };

      // const response = await axios.post(`${this.issuer}oauth/token`, data);

      const response = await axios.post(`${this.issuer}/oauth/token`, {
        grant_type: "http://auth0.com/oauth/grant-type/password-realm",
        realm: "quick-connect",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        username: email,
        password: password,
        scope: "offline_access",
      });

      if (response) {
        const adminResponse = await http.get(
          `${BaseServiceUrl}/v1/admin/${email}`
        );
        if (adminResponse.data === null) {
          const mnstToken = await this.getManagementToken();
          const user = await this.getUserByEmail(mnstToken, email);
          return {
            access_token: response.data.access_token,
            refresh_token: response.data.refresh_token,
            adminId: user.identities[0].user_id,
            isAdminRegistered: false,
          };
        }
        return {
          access_token: response.data.access_token,
          refresh_token: response.data.refresh_token,
          adminId: adminResponse.data,
        };
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 403) {
          this.logger.error(
            `Error For Login, email: ${email}, error: ${error.response.data.error_description}`
          );
          throw new ForbiddenException("Wrong email or password");
        }
      }
      console.log(error);
      throw new BadRequestException("something went wrong");
    }
  }

  async signup(
    email: string,
    password: string,
  ) {
    try {
      const signup_data = {
        client_id: this.clientId,
        email: email,
        password: password,
        connection: "quick-connect",
      };

      const signup_res = await axios.post(
        `${this.issuer}/dbconnections/signup`,
        signup_data
        );

      await this.assignAdminRole(signup_res.data._id);

      const response = await axios.post(`${this.issuer}/oauth/token`, {
        grant_type: "http://auth0.com/oauth/grant-type/password-realm",
        realm: "quick-connect",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        username: email,
        password: password,
        scope: "offline_access",
      });

      return {
        access_token: response.data.access_token,
        refresh_token: response.data.refresh_token,
      };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        // The error.response object contains the HTTP response.
        const response = error.response;

        if (response) {
          // Handle specific error cases based on the response status code or error message.
          if (
            response.status === 400 &&
            response.data.error === "invalid_grant"
          ) {
            // Invalid credentials error
            throw new BadRequestException("Invalid username or password");
          } else {
            // Handle other error cases as needed
            throw new BadRequestException("An error occurred:", response.data);
          }
        } else {
          // Handle network errors, timeouts, or other Axios-related errors.
          console.error("Axios error:", error.message);
        }
      }
      this.logger.error(`Error For SigUp: ${error.message}, email: ${email}`);
      throw error;
    }
  }

  async resendOtp(email: string, task: any) {
    const storedOtp = await this.otpMapRepo.findOne({
      email: email,
      task: task,
    });
    const subjectData = `Verification Email By Qwick Connect`;
    const OtpTemplate = fs.readFileSync(
      "src/auth/templates/otp-template.html",
      "utf8"
    );

    if (storedOtp && storedOtp?.createdAt) {
      // check if otp time is in time limit
      const date = new Date();
      const endTime = moment(date);
      const startTime = moment(storedOtp.createdAt).toDate();
      const timeDiff = endTime.diff(startTime, "minutes");
      if (timeDiff > 10) {
        const otp = generateOtp();
        await this.otpMapRepo.updateOne(
          {
            email: email,
            task: task,
          },
          { otp: otp }
        );
        const mail_context = { otp: otp };
        this.mailService.sendCustomEmail(
          email,
          null,
          subjectData,
          OtpTemplate,
          mail_context
        );
      } else {
        const otp = await this.otpMapRepo.findOne({ email: email, task: task });
        const subjectData = `Verification Email By Qwik Connect`;
        const mail_context = { otp: otp.otp };
        this.mailService.sendCustomEmail(
          email,
          null,
          subjectData,
          OtpTemplate,
          mail_context
        );
      }
    }
  }

  async verifyEmail(email: string) {
    try {
      this.logger.log("Verifying email : " + email);
      const ManagementToken = await this.getManagementToken();
      // get email from auth0
      const user = await this.getUserByEmail(ManagementToken, email);
      if (!user) {
        // create a new otp and store
        const otp = generateOtp();
        await this.otpMapRepo.create({
          email: email,
          otp: otp,
          task: OtpTask.VERIFY_EMAIL,
          createdAt: new Date(),
        });
        console.log("Otp ==>", otp);
        const OtpTemplate = fs.readFileSync(
          "src/auth/templates/otp-template.html",
          "utf8"
        );
        const subjectData = `Verification Email By Qwik Connect`;
        const dynamicData = { otp: otp };
        // Send email with the formatted message
        this.mailService.sendCustomEmail(
          email,
          null,
          subjectData,
          OtpTemplate,
          dynamicData
        );
        return { message: "Not Found" };
      }
      return { message: "Found" };
    } catch (error) {
      this.logger.error(`Error For Verifying Email: ${error.message}`);
      if (error.response) {
        throw new HttpException(
          error.response.statusText,
          error.response.status
        );
      }
    }
  }

  async verifyOtp(email: string, otp: string, task: string) {
    try {
      const storedOtp = await this.otpMapRepo.findOne({
        email: email,
        task: task,
      });
      if (!storedOtp) {
        throw new BadRequestException("Otp Not Found");
      } else if (storedOtp.otp !== otp) {
        throw new BadRequestException("Invalid Otp");
      }
      // check if otp time is in time limit
      const date = new Date();
      const endTime = moment(date);
      const startTime = moment(storedOtp.createdAt).toDate();
      const timeDiff = endTime.diff(startTime, "minutes");
      if (timeDiff > 10) {
        throw new HttpException("expired OTP", HttpStatus.BAD_REQUEST);
      }
      //delete OTP after verification
      await this.otpMapRepo.deleteOne({
        email: email,
        task: task,
      });
      return "Valid";
    } catch (error) {
      this.logger.error(`Error For Verifying Otp: ${error.message}`);
      if (error.response) {
        throw new HttpException(error.response.statusText, 404);
      }
      throw error;
    }
  }

  async getManagementToken(): Promise<string> {
    try {
      const response = await axios.post(`${this.issuer}/oauth/token`, {
        grant_type: "client_credentials",
        audience: `${this.issuer}/api/v2/`,
        client_id: Auth0Config.mng_clientId,
        client_secret: Auth0Config.mng_clientSecret,
      });
      return response.data.access_token;
    } catch (error) {
      this.logger.error(`Error Getting Management Token : ${error}`);
      throw new BadRequestException(error.message);
    }
  }

  async getUserByEmail(token: string, email: string) {
    try {
      const user = await axios.get(`${this.issuer}/api/v2/users-by-email`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: {
          email: email,
        },
      });
      return user?.data[0];
    } catch (error) {
      if (error.response.status === 404) {
        return null;
      }
      this.logger.error(`Error Getting User By Email : ${error}`);
    }
  }

  async resetPassword(email: string, password: string) {
    try {
      //  Get Management API Token
      const ManagementToken = await this.getManagementToken();
      //  Get User By Email
      const user = await this.getUserByEmail(ManagementToken, email);
      if (!user) {
        throw new BadRequestException("User Not Found");
      }
      //  Update User Password
      await axios.patch(
        `${this.issuer}/api/v2/users/${user.user_id}`,
        {
          password: password,
          connection: "quick-connect", // database connection used to store user credentials
        },
        {
          headers: {
            Authorization: `Bearer ${ManagementToken}`,
          },
        }
      );
      return "Reset Success";
    } catch (error) {
      if (error.response.status === 404) {
        throw new BadRequestException("User Not Found");
      }
      this.logger.error(`Error Resetting Password : ${error}`);
      throw error;
    }
  }

  async assignRoles(user_id, roles) {
    try {
      const MGM_Token = await this.getManagementToken();
      const result = await axios.post(
        `${this.issuer}/api/v2/users/auth0|${user_id}/roles`,
        {
          roles: roles,
        },
        {
          headers: {
            Authorization: "Bearer " + MGM_Token,
          },
        }
      );
      return result;
    } catch (error) {
      this.logger.log(`failed to assign roles for ${user_id}`);
    }
  }

  async getRoles() {
    const MGM_Token = await this.getManagementToken();
    const result = await axios.get(
      `${this.issuer}/api/v2/roles?per_page=50&page=0&include_totals=true`,
      {
        headers: {
          Authorization: "Bearer " + MGM_Token,
        },
        params: {
          per_page: 50,
          page: 0,
          include_totals: true,
        },
      }
    );
    return result;
  }

  async assignAdminRole(user_id) {
    const roles = ["rol_cK52QdzfuabyQp2d"];
    const result = await this.assignRoles(user_id, roles);
    return result;
  }

  async assignGuestAdminRole(user_id) {
    const roles = ["rol_dyKeXYBsx7rYWdgZ"];
    const result = await this.assignRoles(user_id, roles);
    return result;
  }

  async ROPFlowLogin(username, password, _guest) {
    try {
      const result = await axios.post(`${this.issuer}/oauth/token`, {
        grant_type: `http://auth0.com/oauth/grant-type/password-realm`,
        realm: _guest === "true" ? "guest-user" : "quick-connect",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        username: username,
        password: password,
      });
      return result;
    } catch (error) {
      if (error.response) {
        this.logger.error(error.response.data);
        throw new BadRequestException(error.response.data);
      }
      this.logger.error(error.message);
      throw new Error(error.message);
    }
  }

  async initiateSocialLogin(): Promise<string> {
    // Implement logic to initiate social login (redirect to Auth0)
    const authUrl = `${this.issuer}/authorize?response_type=code&client_id=tUk2vLwu478a7SxhuCoGvymzi0sHHJVc&redirect_uri=http://localhost:4546/v1/auth/callback&connection=google-oauth2&prompt=login&display=popup&scope=openid profile`;
    return authUrl;
  }

  async handleSocialLoginCallback(code: string): Promise<any> {
    try {
      const tokenUrl = `${this.issuer}/oauth/token`;
      const response: any = await axios.post(tokenUrl, {
        grant_type: "authorization_code",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        code,
        redirect_uri: `${BaseServiceUrl}/v1/auth/callback`,
        scope: "openid profile offline_access",
      });
      const { access_token, refresh_token } = response;
      const user = await this.getUserProfile(access_token);
      //return substring after '|' return user id from sub (google-oauth2|102930123092138019830) => 102930123092138019830

      return { access_token, refresh_token, id: user.sub };
    } catch (error) {
      console.error(error);
    }
  }

  async getUserProfile(accessToken: string): Promise<any> {
    try {
      const profile = await axios.get(`${this.issuer}/userinfo`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      return profile.data;
    } catch (error) {
      if (error.response) {
        this.logger.error(error.response.data);
        throw new BadRequestException("Failed to fetch user profile");
      }
      this.logger.error(error.message);
      throw new BadRequestException(error.message);
    }
  }
}
