export enum MessagesPermissions {
  ADMIN = "read:users",
}
