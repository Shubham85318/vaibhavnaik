import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type OtpMapDocument = HydratedDocument<OtpMap>;

@Schema({
  timestamps: true,
})
export class OtpMap {
  @Prop({ required: true })
  email: string;

  @Prop({ required: true })
  otp: string;

  @Prop({ required: true })
  task: string;

  @Prop({ required: true })
  createdAt: string;
}
export const OtpMapSchema = SchemaFactory.createForClass(OtpMap);
