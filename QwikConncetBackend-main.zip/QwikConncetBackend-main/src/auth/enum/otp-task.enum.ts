export enum OtpTask {
  VERIFY_EMAIL = "verify_email",
  VERIFY_EMAIL_PASSWORD = "verify_email_password",
}
