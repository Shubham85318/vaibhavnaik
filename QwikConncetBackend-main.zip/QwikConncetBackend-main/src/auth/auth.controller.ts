import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Patch,
  Post,
  Query,
  Req,
  Res,
  UseGuards,
} from "@nestjs/common";
import { AuthorizationGuard } from "./gaurds/auth0.gaurd";
import { PermissionsGuard } from "./gaurds/permissions.guard";
import { MessagesPermissions } from "./gaurds/messages.permissions";
import { ApiBody, ApiOperation, ApiQuery, ApiTags } from "@nestjs/swagger";
import { AuthService } from "./auth.service";
import { VerifyOtpDto } from "./dto/verifyOtp.dto";
import { ResetPasswordDto } from "./dto/reset-password.dto";
import axios from "axios";

@ApiTags("Auth - auth Api's")
@Controller({
  path: "auth",
  version: "1",
})
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post("signup")
  @ApiOperation({ description: "SignUp" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "Email",
  })
  @ApiQuery({
    name: "password",
    type: String,
    description: "Password",
  })
  async signup(
    @Query("email") email: string,
    @Query("password") password: string,
    @Res() res
  ) {
    console.log("emauk- ---> ", email, password);
    const result = await this.authService.signup(email, password);
    return res.status(HttpStatus.OK).json(result);
  }

  @Post("login")
  @ApiOperation({ description: "Login For Admin" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "Email",
  })
  @ApiQuery({
    name: "password",
    type: String,
    description: "Password",
  })
  async login(
    @Query("email") email: string,
    @Query("password") password: string,
    @Query("guest") guest: string
  ) {
    console.log("emauk- ---> ", email, password);
    const result = await this.authService.login(email, password);
    return result;
  }

  @Get("verify-email")
  @ApiOperation({ description: "Get Otp On Email" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "Email",
  })
  async verifyEmail(@Query("email") email: string, @Res() res) {
    console.log("email", { email });
    const response = await this.authService.verifyEmail(email);
    return res.status(HttpStatus.OK).json(response);
  }

  @Post("resend-otp")
  @ApiOperation({ description: "Resend otp" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "Email",
  })
  @ApiQuery({
    name: "task",
    type: String,
    description:
      "Task for Otp Type , Types Are : verify_email,verify_email_password",
  })
  async resendOtp(
    @Query("email") email: string,
    @Query("task") task,
    @Res() res
  ) {
    await this.authService.resendOtp(email, task);
    return res.status(HttpStatus.OK).send();
  }

  @Post("verify-otp")
  @ApiOperation({ description: "Verify Otp Sent On Email" })
  @ApiBody({
    type: VerifyOtpDto,
  })
  async verifyOtp(@Body() body: VerifyOtpDto, @Res() res) {
    const { email, otp, task } = body;
    const response = await this.authService.verifyOtp(email, otp, task);
    return res.status(HttpStatus.OK).json(response);
  }

  @Patch("resetPassword")
  @ApiOperation({ description: "Reset Password" })
  @ApiBody({
    type: ResetPasswordDto,
  })
  async resetPassword(@Body() body, @Res() res) {
    const { email, password } = body;
    const response = await this.authService.resetPassword(email, password);
    return res.status(HttpStatus.OK).json(response);
  }

  @Get("public")
  @UseGuards(AuthorizationGuard)
  async getPublic() {
    return {
      text: "This is a public message.",
    };
  }

  @UseGuards(AuthorizationGuard)
  @Get("protected")
  async getProtected() {
    return {
      text: "This is a protected message.",
    };
  }

  @UseGuards(
    AuthorizationGuard,
    PermissionsGuard(["read:users", "update:users"])
  )
  @Get("permissions")
  async getProtectPermissions() {
    return {
      text: "This is a protected message.",
    };
  }

  @UseGuards(PermissionsGuard([MessagesPermissions.ADMIN]))
  @UseGuards(AuthorizationGuard)
  @Get("admin")
  async getAdmin() {
    return {
      text: "This is an admin message.",
    };
  }

  @Get("/login-google")
  async redirectToAuth0(@Res() res) {
    const authUrl = await this.authService.initiateSocialLogin();
    return res.json(authUrl);
  }

  @Get("/callback")
  async handleAuth0Callback(@Query("code") code: string, @Res() res) {
    try {
      const tokenData = await this.authService.handleSocialLoginCallback(code);
      const { access_token, refresh_token, id } = tokenData; // Extract the access token

      // Redirect back to the UI with the access token as a query parameter
      return res.redirect(
        `http://localhost:5173/dashboard/home?access_token=${access_token}&refresh_token=${refresh_token}&id=${id}`
      );
    } catch (error) {
      console.error(error);
      return res.status(500).json({ error: "Failed to handle callback" });
    }
  }

  @Get("/user-profile")
  async getUserProfile(
    @Query("accessToken") accessToken: string
  ): Promise<any> {
    const profileResponse = await axios.get(
      "https://www.googleapis.com/oauth2/v3/userinfo",
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    return profileResponse.data;
  }
}
