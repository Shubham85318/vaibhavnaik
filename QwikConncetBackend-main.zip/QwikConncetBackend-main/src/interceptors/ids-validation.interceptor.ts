import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from "@nestjs/common";
import { Observable } from "rxjs";
import { AdminService } from "src/admin/admin.service";
import { IntervieweeService } from "src/interviewee/interviewee.service";
import { JobPostService } from "src/job-post/job-post.service";

@Injectable()
export class IdValidationInterceptor implements NestInterceptor {
  constructor(
    private adminService: AdminService,
    private jobPostService: JobPostService,
    private intervieweeService: IntervieweeService
  ) {}
  async intercept(
    context: ExecutionContext,
    next: CallHandler
  ): Promise<Observable<any>> {
    const req = context.switchToHttp().getRequest();
    const res = context.switchToHttp().getResponse();
    const adminId: string = req?.query?.adminId as string;
    const jobPostId: string = req?.query?.jobPostId as string;
    const intervieweeId: string = req?.query?.intervieweeId as string;

    if (adminId) {
      // Validate the AdminId
      await this.adminService.validateAdmin(adminId);

      if (jobPostId) {
        // Validate the jobPostId
        await this.jobPostService.validateJob(adminId, jobPostId);

        if (intervieweeId) {
          // Validate the intervieweeId
          await this.intervieweeService.validateInterviewee(
            adminId,
            jobPostId,
            intervieweeId
          );
        }
      }
    }
    return next.handle();
  }
}
