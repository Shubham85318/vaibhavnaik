import { ApiProperty } from "@nestjs/swagger";
import { IsEmpty, IsString } from "class-validator";

export class updateBasicDto {
  @ApiProperty({ name: "jobTitle", required: true, description: "jobTitle" })
  @IsEmpty()
  @IsString()
  jobTitle: string;

  @ApiProperty({
    name: "jobDescription",
    required: true,
    description: "jobDescription",
  })
  @IsString()
  @IsEmpty()
  jobDescription: string;

  @ApiProperty({ name: "hiringLocation", description: "hiringLocation" })
  @IsString()
  @IsEmpty()
  hiringLocation: string;

  @ApiProperty({
    name: "requiredExperience",
    description: "requiredExperience",
  })
  @IsString()
  @IsEmpty()
  requiredExperience: string;
}
