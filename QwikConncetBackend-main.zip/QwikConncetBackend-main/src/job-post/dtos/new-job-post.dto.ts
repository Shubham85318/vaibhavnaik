import { IsNotEmpty, IsString } from "class-validator";

export class loginHeaderDto {
  @IsString({ message: "name must be string" })
  name: string;
}

export class tokenHeaderDto {
  @IsNotEmpty()
  @IsString()
  client_id: string;

  @IsNotEmpty()
  @IsString()
  device_id: string;
}
