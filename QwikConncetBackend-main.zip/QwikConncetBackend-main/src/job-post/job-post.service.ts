import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  NotFoundException,
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { JobPost, JobPostDocument } from "./schemas/jobPost.schema";
import { Model } from "mongoose";
import { ObjectId } from "mongodb";
import { createPrivateLinks } from "src/utils/create-private-link";
import { S3ManagerService } from "src/shared/s3.module.service";
import { JobPostStatus } from "./enum/job-post-status.enum";
import { Readable } from "stream";
import {
  filterQuestions,
  generateUUID,
  getRandomQuestions,
} from "src/utils/jobPost.utils";
import * as http from "../utils/http.util";
import { BaseServiceUrl, qwik_connect_domain } from "src/config";
import * as fs from "fs";
import { MailService } from "src/shared/mail.service";
import axios from "axios";

@Injectable()
export class JobPostService {
  constructor(
    @InjectModel(JobPost.name)
    private readonly jobPostRepo: Model<JobPostDocument>,
    private readonly s3ManagerService: S3ManagerService,
    private readonly mailService: MailService,
    private readonly logger: Logger
  ) {}

  async getJobPostStatus(adminId: string, jobPostId: string) {
    const status = await this.jobPostRepo.findOne(
      { _id: new ObjectId(jobPostId), adminId: adminId },
      { status: 1 }
    );
    return status;
  }

  // add empty JobPost
  async addJobPost(adminId: string) {
    try {
      // check if Draft having JobPost
      const response = await http.get(
        `${BaseServiceUrl}/v1/admin/draft-jobpost`,
        {
          params: {
            adminId,
          },
        }
      );
      let jobPost;
      if (response.data === "") {
        const timeStamp = new Date().getTime();
        const createdJobPost = await this.jobPostRepo.create({
          adminId: adminId,
        });
        // const createdJobPost = await this.jobPostRepo.create({adminId: adminId})
        const publicLink = `${qwik_connect_domain}/${adminId}/${createdJobPost._id}/${timeStamp}`;
        jobPost = await this.jobPostRepo.findByIdAndUpdate(
          createdJobPost._id,
          { publicLink: publicLink, status: JobPostStatus.DRAFT },
          { new: true }
        );
        await http.post(
          `${BaseServiceUrl}/v1/admin/draft-jobpost`,
          {},
          {
            params: {
              adminId,
              jobPostId: jobPost._id.toString(),
            },
          }
        );
      } else {
        jobPost = await this.jobPostRepo.findById(new ObjectId(response.data));
      }
      return jobPost;
    } catch (error) {
      this.logger.error(
        `Error Creating JobPost for adminId: ${adminId}`,
        error
      );
      throw new HttpException(
        `Error Creating JobPost for adminId: ${adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async deleteJobPost(jobPostId: string) {
    const jobPost = await this.jobPostRepo.findByIdAndDelete({ id: jobPostId });
    if (!jobPost) return "jobPost not found";
    await this.jobPostRepo.findByIdAndDelete({ id: jobPostId });
    return "jobPost deleted";
  }

  async updateJobBasic(body: any, jobPostId: string) {
    try {
      const JobpostId = new ObjectId(jobPostId);
      const updatedJobPost = await this.jobPostRepo.findByIdAndUpdate(
        { _id: JobpostId },
        body,
        { new: true }
      );
      return updatedJobPost;
    } catch (error) {
      this.logger.error(
        `Error updating Jobpost Basic Details, Error: ${error.message}`,
        error
      );
      throw new BadRequestException("Error updating Jobpost");
    }
  }

  async createNewJobPost(body) {
    try {
      this.logger.log(`new job adding... ${body.adminId}`, "CreateNewJob");
      const jobPostObject = {
        ...body,
        status: JobPostStatus.DEACTIVATE,
      };
      const new_job = (await this.jobPostRepo.create(body)).save();
      return new_job;
    } catch (error) {
      this.logger.error(
        `error in new job adding... ${error}`,
        "",
        "CreateNewJob"
      );
      throw new error();
    }
  }

  async updateJobPost(body, jobPostId) {
    try {
      const {
        display_questions,
        ratingParameters,
        requiredRatingParameter,
      } = body;

      // adding parameters to jobPost
      const jobPost = await this.jobPostRepo.findOneAndUpdate(
        { _id: jobPostId },
        {
          $set: {
            ratingParameters: ratingParameters,
            requiredRatingParameter: requiredRatingParameter,
            displayQuestions: display_questions,
          },
        },
        { new: true }
      );
      return jobPost;
    } catch (error) {
      this.logger.error(
        `Error Adding Parameters And Question... for adminId: ${body.adminId}, JobPostId: ${body.jobPostId}, Error: ${error}`);
      throw new HttpException(
        `Error Updating Job ...${body.adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async addQuestion(body: any, file: Express.Multer.File, adminId, jobPostId) {
    try {
      // const { question } = body;

      // find if jobPost is present already
      const jobPost = await this.jobPostRepo.findById(new ObjectId(jobPostId));
      if (!jobPost) {
        // Handle the case where the JobPost document is not found
        throw new Error(`JobPost with ID ${jobPostId} not found.`);
      }

      if (file) {
        //upload video
        const uuid = generateUUID();
        const Key = `admins/${adminId}/jobpost/${jobPostId}/questions/${uuid}/${file.originalname}`;
        this.uploadMultipart(Key, file, "question");

        // update video key to questionBank
        body.questionVideoKey = Key;
      }
      const updatedJobPost = await this.jobPostRepo.findByIdAndUpdate(
        { _id: jobPostId },
        { $push: { questionBank: body } },
        { new: true }
      );
      return updatedJobPost;
    } catch (error) {
      this.logger.error(error);
      this.logger.error(
        `Error Adding Question... for adminId: ${body.adminId},
        JobPostId: ${body.jobPostId}, ${error}`,
        "",
        "AddQuestion"
      );
      throw new HttpException(
        `Error Updating Job ...${body.adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async updateBranding(colors, file, adminId, jobPostId) {
    try {
      // upload logo
      console.log("branding", colors);
      let branding = {};
      if (file) {
        const Key = `admins/${adminId}/jobpost/${jobPostId}/branding/${file.originalname}`;
        this.s3ManagerService.uploadImage(Key, file, "LOGO");
        branding = {
          logo: Key,
          color: {
            primaryBrandColor: colors.primary_brand_colour,
            secondaryBrandColor: colors.secondary_brand_colour,
          },
        };
      } else {
        branding = {
          color: {
            primaryBrandColor: colors.primary_brand_colour,
            secondaryBrandColor: colors.secondary_brand_colour,
          },
        };
      }
      const result = await this.jobPostRepo.findOneAndUpdate(
        { _id: new ObjectId(jobPostId) },
        { $set: { branding: branding } },
        { new: true }
      );
      return result;
    } catch (error) {
      this.logger.error(
        `Error adding branding ... ${error}`,
        "",
        "AddBranding"
      );
      throw new HttpException(
        `Error adding branding ...${adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async updatePublishLink(jobPostId, adminId, csvData) {
    try {
      let privateLinks;
      if (csvData) {
        // to pass jobpost data to email template
        // const jobPost = await this.jobPostRepo.findOne({id: new ObjectId(jobPostId)});
        privateLinks = createPrivateLinks(adminId, jobPostId, csvData);
        // send private links to email address
        //give csv data and array of users with links and template name
        this.sendMailLinks(privateLinks, csvData);
      }
      const result = await this.jobPostRepo.findByIdAndUpdate(
        new ObjectId(jobPostId),
        {
          $set: {
            privateLinks: privateLinks,
            status: JobPostStatus.ACTIVE,
            publishAt: new Date(),
          },
        },
        { new: true }
      );
      await http.post(
        `${BaseServiceUrl}/v1/admin/draft-clear`,
        {},
        {
          params: {
            adminId,
            jobPostId,
          },
        }
      );
      return result;
    } catch (error) {
      this.logger.error(
        `Error publishing link ... ${error}`,
        "",
        "PublishLink"
      );
      throw new HttpException(
        `Error publishing link ...${adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async sendMailLinks(Mails: any[], csvData: any) {
    const Template = fs.readFileSync(
      "src/job-post/mail-template/interview-invitation-template.html",
      "utf8"
    );
    console.log(Template);

    csvData.forEach(async (data, index) => {
      const context = {
        candidateName: data.Name,
        hiringCompanyName: "Qwik-Connect",
        contactEmail: "quick connect contact email",
        interviewLink: Mails[index],
        interviewerName: "qwik admin",
        companyName: "qwik connect",
        contactEmailPhone: "+91 9922334412",
        marketingInputs: "Marketing Inputs",
        yourName: "Qwik Connect",
        yourTitle: "Qwik Connect",
      };
      //   recipientEmail: string,
      // replyToEmail: string,
      // subject: string,
      // body: string, // HTML body of the email template
      // context: Record<string, string> // Dynamic data as key-value pairs
      const subject = "Interview Invitation by Qwik Connect";
      await this.mailService.sendCustomEmail(
        data.Email,
        null,
        subject,
        Template,
        context
      );
    });
  }

  async getAllJobPosts(adminId: string) {
    try {
      this.logger.log("inside get jobPost...");
      const allJobPostData = await this.jobPostRepo.find(
        {
          adminId: adminId,
          status: { $in: [JobPostStatus.ACTIVE, JobPostStatus.DEACTIVATE] },
        },
        {
          _id: 1,
          jobTitle: 1,
          hiringLocation: 1,
          requiredExperience: 1,
          application: 1,
          shortlisted: 1,
          rejected: 1,
        }
      );

      if (allJobPostData.length === 0) return [];

      const jobPosts = allJobPostData.map((job) => {
        return job._id.toString();
      });
      const statistics = await this.getStatisticsForJobPosts(jobPosts);

      const _jobPosts = allJobPostData.map((job, index) => {
        const { jobTitle, hiringLocation, requiredExperience, publishAt,_id } = job;
        if (statistics[index].id === job.id) {
          return {
            ...statistics[index],
            _id,
            jobTitle,
            hiringLocation,
            requiredExperience,
            publishAt,
          };
        }
      });

      return _jobPosts;
    } catch (error) {
      this.logger.error(`Error get jobPosts..`, error);
      throw new HttpException(
        `Error fetch jobPosts ...${adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getJobPostDetail(adminId: string, jobPostId: string) {
    try {
      this.logger.log("inside get job post ...");
      const jobPost = await this.jobPostRepo.findOne({
        _id: new ObjectId(jobPostId),
        adminId: adminId,
      });
      const candidates = await http.get(`${BaseServiceUrl}/interviewee`, {
        params: { adminId, jobPostId },
      });
      const IntervieweeData = await http.get(
        `${BaseServiceUrl}/v1/interviewee/statistics`,
        {
          params: { jobPostId: jobPostId },
        }
      );
      return { jobPost, candidates, IntervieweeData };
    } catch (error) {
      this.logger.error(`Error get jobPost..`, error);
      throw new HttpException(
        `Error fetch jobPost ...${adminId},${jobPostId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getQuestionsByBankId(adminId: string, jobPostId: string) {
    const jobPost = await this.jobPostRepo.findOne(
      { _id: new ObjectId(jobPostId) },
      { questionBank: 1, displayQuestions: 1, ratingParameters: 1 }
    );
    const { mandatoryQuestions, rest } = filterQuestions(jobPost.questionBank);
    const restToSelect = jobPost.displayQuestions - mandatoryQuestions?.length;
    const restQuestion = getRandomQuestions(restToSelect, rest);
    const combineQuestionBank = [...mandatoryQuestions, ...restQuestion];
    const parameters = {};
    jobPost.ratingParameters.forEach((field) => (parameters[field] = -1));
    return { questionBank: combineQuestionBank, parameters: parameters };
  }

  async getActiveJobPost(adminId: string) {
    try {
      this.logger.log(`fetching active jobPost for ${adminId}`);
      const activeJobPostData = await this.jobPostRepo.find(
        {
          adminId: adminId,
          status: JobPostStatus.ACTIVE,
        },
        {
          _id: 1,
          jobTitle: 1,
          hiringLocation: 1,
          requiredExperience: 1,
          publishAt: 1,
        }
      );
      
      if (activeJobPostData.length === 0) return [];

      const jobPosts = activeJobPostData.map((job) => {
        return job._id.toString();
      });

      const statistics = await this.getStatisticsForJobPosts(jobPosts);

      const _jobPosts = activeJobPostData.map((job, index) => {
        const { jobTitle, hiringLocation, requiredExperience, publishAt,_id } = job;
        if (statistics[index].id === job.id) {
          return {
            ...statistics[index],
            jobTitle,
            _id,  
            hiringLocation,
            requiredExperience,
            publishAt,
          };
        }
      });

      return _jobPosts;
    } catch (error) {
      this.logger.error("Error fetching Active JobPost:", error);
      throw new HttpException(
        `Error Fetching Active JobPost for ${adminId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getVideoById(key: string) {
    const stream = await this.s3ManagerService.getVideoStreamFromS3(key);
    return stream;
  }

  //upload multipart with s3ManagerService
  async uploadMultipart(key: string, file, type) {
    try {
      const uploadId = await this.s3ManagerService.startMultipartUpload(key);
      console.log("started multipart upload !!");

      // Convert the file buffer to a Readable stream
      const dataStream = Readable.from(file.buffer);

      const parts = [];
      let partNumber = 1;

      console.log("uploading chunks !");

      for await (const chunk of dataStream) {
        const partETag = await this.s3ManagerService.uploadPart(
          key,
          partNumber,
          uploadId,
          chunk
        );
        parts.push({ PartNumber: partNumber, ETag: partETag });
        partNumber++;
      }

      await this.s3ManagerService.completeMultipartUpload(key, uploadId, parts);

      console.log(`Video uploaded successfully of type: ${type},key: ${key}`);
    } catch (error) {
      this.logger.error(`Error uploading Multipart ${error}`);
      this.logger.error(`failed to upload video of type: ${type},key: ${key}`);
    }
  }

  async getJobDetails(adminId: string, jobPostId: any, token) {
    try {
      const admin = await http.get(
        `${BaseServiceUrl}/v1/admin/validate-admin`,
        {
          params: {
            adminId: adminId,
          },
        }
      );
      if (!admin) throw new NotFoundException("Admin not found");
      const job_data = await this.jobPostRepo.findById(jobPostId);
      if (!job_data) {
        throw new HttpException(
          `Error while fetching data for  this job post ${jobPostId}`,
          404
        );
      }
      const IntervieweeData = await axios.get(
        `${BaseServiceUrl}/v1/interviewee/statistics`,
        {
          params: { adminId: adminId, jobPostId: jobPostId },
          headers: {
            Authorization: token,
          },
        }
      );
      const newData = {
        hiringLocation: job_data.hiringLocation,
        jobDescription: job_data.jobDescription,
        jobTitle: job_data.jobTitle,
        requiredExperience: job_data.requiredExperience,
        status: job_data.status,
        passingPoint: job_data.passingPoint,
        stats: IntervieweeData.data,
        requiredRatingParameter: job_data.requiredRatingParameter,
        publishAt: job_data.publishAt
      };
      return newData;
    } catch (error) {
      console.log("error", error);
      throw new HttpException(
        `Error while fetching data for  this job post ${jobPostId}`,
        404
      );
    }
  }

  async validateJob(adminId: string, jobPostId: string) {
    // const admin = await http.get(`${BaseServiceUrl}/v1/admin/validate-admin`, {
    //   params: {
    //     adminId: adminId
    //   }
    // });
    // if (!admin) throw new NotFoundException("Admin not found");
    const job = this.jobPostRepo.findOne({
      _id: new ObjectId(jobPostId),
      adminId: adminId,
    });
    if (!job) throw new NotFoundException("Job not found");
  }

  async getStatistics(adminId: string = null, jobPostId: string = null) {
    const response = await http.get(
      `${BaseServiceUrl}/v1/interviewee/statistics`,
      {
        params: {
          adminId: adminId,
        },
      }
    );
    return response.data;
  }
  async getStatisticsForJobPosts(jobPosts) {
    try {
      const response = await http.get(
        `${BaseServiceUrl}/v1/interviewee/statistics/jobs`,
        {
          params: {
            jobPosts: jobPosts,
          },
        }
      );
      return response.data;
    } catch (error) {
      this.logger.error(error);
      throw new BadRequestException(
        `Error to fetch Statistics for jobPosts: ${error.message}`
      );
    }
  }

  async deleteQuestion(jobPostId: string, questionId: string) {
    const JobPostId = new ObjectId(jobPostId);
    const QuestionId = new ObjectId(questionId);
    const response = await this.jobPostRepo.findByIdAndUpdate(
      JobPostId,
      { $pull: { questionBank: { _id: QuestionId } } },
      { new: true }
    );
    return response.questionBank;
  }
}
