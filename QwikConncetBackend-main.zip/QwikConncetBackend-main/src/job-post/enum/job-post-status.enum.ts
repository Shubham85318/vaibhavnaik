export enum JobPostStatus {
  ACTIVE = "ACTIVE",
  DEACTIVATE = "DEACTIVATE",
  DRAFT = "DRAFT",
}
