import {
  Body,
  Controller,
  Delete,
  Get,
  Headers,
  HttpException,
  HttpStatus,
  Logger,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Res,
  UploadedFile,
  UseInterceptors,
} from "@nestjs/common";
import { JobPostService } from "./job-post.service";
import { FileInterceptor } from "@nestjs/platform-express";
import {
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from "@nestjs/swagger";
import { updateBasicDto } from "./dtos/update-basic.dto";
import { readFile } from "fs/promises";
import { readCsvFile } from "src/utils/csvReader";
import { readTxtFile } from "src/utils/jobPost.utils";

@ApiTags("JobPost - Schedule Interview APIs")
@Controller({
  path: "job-post",
  version: "1",
})
export class JobPostController {
  constructor(
    private readonly jobPostService: JobPostService,
    private readonly logger: Logger
  ) {}

  @Get()
  @ApiOperation({ description: "Get All jobPost's by AdminId" })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: true,
    description: "AdminId",
  })
  async getJobPosts(@Query("adminId") adminId: string, @Res() res) {
    console.log("hello");
    console.log(adminId);
    const result = await this.jobPostService.getAllJobPosts(adminId);
    return res.status(HttpStatus.OK).json(result);
  }

  @Delete(":jobPostId")
  @ApiOperation({ description: "Delete JobPosts" })
  @ApiParam({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  async deleteJobPost(@Param("jobPostId") jobPostId: string, @Res() res) {
    const result = await this.jobPostService.deleteJobPost(jobPostId);
    return res.status(HttpStatus.OK).json(result);
  }

  @Get("active")
  @ApiOperation({ description: "Get Active jobPost's by AdminId" })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: true,
    description: "AdminId",
  })
  async getActiveJobPost(@Query("adminId") adminId: string, @Res() res) {
    const result = await this.jobPostService.getActiveJobPost(adminId);
    return res.status(HttpStatus.OK).json(result);
  }

  @Get("status")
  @ApiOperation({ description: " Get JobPost Status" })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: true,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    required: true,
    description: "JobPostId",
  })
  async getJobPostStatus(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    const result = await this.jobPostService.getJobPostStatus(
      adminId,
      jobPostId
    );
    return res.status(HttpStatus.OK).json(result);
  }

  @Get("detail")
  @ApiOperation({ description: "Get jobPost detail by adminId and jobPostId" })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: true,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    required: true,
    description: "JobPostId",
  })
  async getJobPostDetail(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    const result = await this.jobPostService.getJobPostDetail(
      adminId,
      jobPostId
    );
    return res.status(HttpStatus.OK).json(result);
  }

  @Post()
  @ApiOperation({ description: "Add JobPost with AdminId Only" })
  @ApiQuery({
    name: "adminId",
    required: true,
    type: String,
    description: "Registered AdminId",
  })
  async addJobPost(@Query("adminId") adminId: string, @Res() res) {
    console.log("adminId", adminId);
    const result = await this.jobPostService.addJobPost(adminId);
    return res.status(HttpStatus.OK).json(result);
  }

  @Put("basic")
  @ApiOperation({ description: "Save Basic Details Of Admin" })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    required: true,
    description: "jobPostId",
  })
  @ApiBody({
    type: updateBasicDto,
    required: true,
  })
  async saveBasicDetails(
    @Query("jobPostId") jobPostId: string,
    @Body() body: updateBasicDto,
    @Res() res
  ) {
    console.log("hello", body, jobPostId);
    const result = await this.jobPostService.updateJobBasic(body, jobPostId);
    console.log("result", result);
    return res.status(HttpStatus.OK).json(result);
  }

  @Put("parameters") // update parameter and question
  @ApiOperation({ description: "Add question and parameters to JobPost" })
  async addQuestionAndParameters(
    @UploadedFile() file: Express.Multer.File,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Body() body,
    @Res() res
  ) {
    await this.jobPostService.updateJobPost(
      body,
      jobPostId
    );
    return res.status(HttpStatus.OK).send();
  }

  @Post("question")
  @ApiOperation({ description: "Add Single Question" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @ApiBody({
    type: Object,
  })
  @UseInterceptors(FileInterceptor("file"))
  async addQuestion(
    @UploadedFile() file: Express.Multer.File,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Body("jsonData") jsonData,
    @Res() res
  ) {
    const jsonDataObject = JSON.parse(jsonData);
    console.log("json", jsonDataObject);
    const result = await this.jobPostService.addQuestion(
      jsonDataObject,
      file,
      adminId,
      jobPostId
    );
    console.log("result", result);
    return res.status(HttpStatus.OK).json(result);
  }

  @Put("branding")
  @ApiOperation({ description: "update the branding" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @UseInterceptors(FileInterceptor("file"))
  async addBranding(
    @UploadedFile() file: Express.Multer.File,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Body("json_data") json_data,
    @Res() res
  ) {
    try {
      console.log(file);
      console.log(json_data);
      const jsonDataObject = JSON.parse(json_data);
      const result = await this.jobPostService.updateBranding(
        jsonDataObject,
        file,
        adminId,
        jobPostId
      );
      return res.status(HttpStatus.OK).json(result);
    } catch (error) {
      throw error;
    }
  }

  @Put("publish-link")
  @ApiOperation({ description: "Public Links" })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: true,
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    required: true,
  })
  @UseInterceptors(FileInterceptor("csvFile"))
  async uploadCsvFile(
    @UploadedFile() csvFile: Express.Multer.File,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    try {
      // if(!csvFile) throw new NotFoundException("csvFile not provided");
      let csvData = undefined;
      if (csvFile) {
        const csvStream = csvFile.buffer.toString(); // Get the CSV data from the buffer
        csvData = await readCsvFile(csvStream);
      }
      const result = await this.jobPostService.updatePublishLink(
        jobPostId,
        adminId,
        csvData
      );
      return res.status(HttpStatus.OK).json(result);
    } catch (error) {
      throw error;
    }
  }

  @Get("csv")
  @ApiOperation({ description: "Download Sample Csv" })
  async getCsvExample(@Res() res) {
    try {
      const filePath = "src/job-post/asset/bulk_invite_example.csv";
      const csvData = await readFile(filePath, "utf-8");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="example-csv"'
      );
      res.send(csvData);
    } catch (error) {
      this.logger.error(`Error Reading Csv File`, error.message);
      throw new HttpException("Error ReadingCsv File", HttpStatus.BAD_REQUEST);
    }
  }

  @Get("invitation-template")
  @ApiOperation({ description: "Download Invitation Template" })
  async getInvitationTemplate(@Res() res) {
    try {
      const filePath = "src/job-post/asset/Invitation_template.txt";
      const content = await readTxtFile(filePath);
      res.contentType("text/plain");
      res.send(content);
    } catch (error) {
      this.logger.error(`Error reading TextFile for Template`, error);
      res.status(500).send("Error reading file");
    }
  }

  @Get("question-bank/allot")
  @ApiOperation({
    description: "Get QuestionBank With Alloted No Of Questions",
  })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  async getQuestionBank(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    const result = await this.jobPostService.getQuestionsByBankId(
      adminId,
      jobPostId
    );
    return res.json(result);
  }

  @Get("question/:key")
  @ApiOperation({
    description: "Get question video by JobPostId, questionId",
  })
  async getQuestion(@Param("key") key: string, @Res() res) {
    try {
      const videoStream = await this.jobPostService.getVideoById(key);
      const contentType = "video/mp4";

      res.setHeader("Content-Disposition", `attachment; filename="${key}"`);
      res.setHeader("Content-Type", contentType);

      videoStream.pipe(res);
    } catch (error) {
      console.error("Error fetching video:", error);
      throw new HttpException("Failed to fetch video", HttpStatus.BAD_REQUEST);
    }
    return "hello";
  }

  @Get("get-job-detail")
  async getJobDetails(
    @Res() res,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Headers("Authorization") token: string
  ) {
    try {
      const job_data = await this.jobPostService.getJobDetails(
        adminId,
        jobPostId,
        token
      );
      return res.status(HttpStatus.OK).json(job_data);
    } catch (error) {
      return res
        .status(HttpStatus.BAD_REQUEST)
        .json("Error while fetching the basic details of job");
    }
  }

  @Get("validate")
  @ApiOperation({ description: "Validate JobPost" })
  @ApiQuery({
    name: "adminId",
    type: String,
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
  })
  async validateJoPost(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string
  ) {
    const response = await this.jobPostService.validateJob(adminId, jobPostId);
    return response;
  }

  @Patch("question")
  @ApiOperation({ description: "Delete Single Question" })
  @ApiQuery({
    name: "jobPostId",
    type: "string",
    description: "JobPostId",
  })
  @ApiQuery({
    name: "questionId",
    type: "string",
    description: "QuestionId",
  })
  async deleteQuestion(
    @Query("jobPostId") jobPostId: string,
    @Query("questionId") questionId: string,
    @Res() res
  ) {
    console.log("jobPostId", jobPostId);
    const response = await this.jobPostService.deleteQuestion(
      jobPostId,
      questionId
    );
    return res.status(HttpStatus.OK).json(response);
  }
}
