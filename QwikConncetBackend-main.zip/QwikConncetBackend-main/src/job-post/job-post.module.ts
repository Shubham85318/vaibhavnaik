import { Logger, Module } from "@nestjs/common";
import { JobPostController } from "./job-post.controller";
import { JobPostService } from "./job-post.service";
import { MongooseModule } from "@nestjs/mongoose";
import { JobPost, JobPostSchema } from "./schemas/jobPost.schema";
import { IntervieweeModule } from "src/interviewee/interviewee.module";
import { Question, QuestionSchema } from "./schemas/question.schema";
import { S3ManagerService } from "src/shared/s3.module.service";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: JobPost.name, schema: JobPostSchema },
      { name: Question.name, schema: QuestionSchema },
    ]),
    IntervieweeModule,
  ],
  controllers: [JobPostController],
  providers: [JobPostService, Logger, S3ManagerService],
  exports: [JobPostService],
})
export class JobPostModule {}
