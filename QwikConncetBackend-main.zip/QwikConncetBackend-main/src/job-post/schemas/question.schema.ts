import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type QuestionDocument = HydratedDocument<Question>;

@Schema({})
export class Question {

  @Prop()
  questionTitle: string;

  @Prop({})
  questionVideoKey: string;

  @Prop({})
  isMandatory: boolean;

  @Prop({})
  retakes: number;

  @Prop({})
  thinkingTime: string; //'seconds'

  @Prop({})
  timeToAnswer: string; //'seconds'

  @Prop()
  jobPostId: string;
}

export const QuestionSchema = SchemaFactory.createForClass(Question);
