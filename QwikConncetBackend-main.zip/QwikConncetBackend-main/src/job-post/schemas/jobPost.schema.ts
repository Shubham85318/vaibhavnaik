import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";
import { Branding, BrandingSchema } from "./branding.schema";
import { Question, QuestionSchema } from "./question.schema";
import { JobPostStatus } from "../enum/job-post-status.enum";

export type JobPostDocument = HydratedDocument<JobPost>;

@Schema()
export class JobPost {
  @Prop()
  jobTitle: string;

  @Prop({ required: true })
  adminId: string;

  @Prop({})
  jobDescription: string;

  @Prop({})
  hiringLocation: string;

  @Prop({})
  requiredExperience: string;

  @Prop({ default: JobPostStatus.DEACTIVATE })
  status: string;

  @Prop({})
  profession: string;

  @Prop({
    default: ["Concentration", "Flexible", "Competency", "Skills", "Aptitude"],
  })
  ratingParameters: [string];

  @Prop()
  requiredRatingParameter: number;

  @Prop({default:3})
  passingPoint: number;

  @Prop([Question])
  questionBank: Question[]; //array of question id

  @Prop({ type: BrandingSchema }) // it will contain Branding for JobPost
  branding: Branding;

  @Prop({})
  displayQuestions: number;

  @Prop({})
  publicLink: string;

  @Prop({})
  publishAt: Date;

  @Prop({})
  privateLinks: string[];

  @Prop({})
  emailTemplate: string;

  @Prop({})
  interviewee: []; // array of interviewee's who registered for JopPost

  @Prop({})
  createdBy: string;

  @Prop({})
  updatedBy: string;

  @Prop({})
  deleteBy: string;
}

export const JobPostSchema = SchemaFactory.createForClass(JobPost);
