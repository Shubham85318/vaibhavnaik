import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type BrandingDocument = HydratedDocument<Branding>;

@Schema()
export class Branding {
  @Prop({ required: true })
  adminId: string;

  @Prop()
  jobPostId: string; //contains key for jobPostId

  @Prop()
  logo: string; // contains array of key from s3 bucket

  @Prop({
    type: {
      primaryBrandColor: String,
      secondaryBrandColor: String,
    },
  })
  color: {
    primaryBrandColor: string;
    secondaryBrandColor: string;
  };
}

export const BrandingSchema = SchemaFactory.createForClass(Branding);
