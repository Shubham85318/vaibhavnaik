import { Injectable } from "@nestjs/common";
import {
  SESClient,
  SendEmailCommand,
  SendBulkTemplatedEmailCommand,
} from "@aws-sdk/client-ses";
import { SES_CONFIG } from "src/config";

@Injectable()
export class MailService {
  private sesClient: SESClient;

  constructor() {
    this.sesClient = new SESClient(SES_CONFIG);
  }

  async sendCustomEmail(
    recipientEmail: string,
    replyToEmail: string,
    subject: string,
    body: string, // HTML body of the email template
    context: Record<string, string> // Dynamic data as key-value pairs
  ): Promise<any> {
    // Replace placeholders in the body with dynamic data
    const personalizedBody = Object.keys(context).reduce(
      (updatedBody, key) =>
        updatedBody.replace(new RegExp(`{{${key}}}`, "g"), context[key]),
      body
    );

    const sendEmailCommand = new SendEmailCommand({
      Source: process.env.AWS_SES_SENDER, // Replace with your verified email
      Destination: { ToAddresses: [recipientEmail] },
      ReplyToAddresses: [replyToEmail], // Add reply-to address here
      Message: {
        Subject: {
          Data: subject,
          Charset: "UTF-8",
        },
        Body: {
          Html: {
            Data: personalizedBody,
            Charset: "UTF-8",
          },
        },
      },
    });

    try {
      const response = await this.sesClient.send(sendEmailCommand);
      console.log("Email Has Been Sent", response);
      return response;
    } catch (error) {
      console.error("Error sending custom email:", error);
      throw error;
    }
  }

  async sendBulkMail(
    CcAddresses: string[],
    ToAddresses: string[],
    Template: string,
    ReplacementTemplateData
  ) {
    const params = {
      Destinations: [
        {
          Destination: {
            CcAddresses: CcAddresses,
            ToAddresses: ToAddresses,
          },
          ReplacementTemplateData:
            '{ "REPLACEMENT_TAG_NAME":"REPLACEMENT_VALUE" }',
        },
      ],
      Source: process.env.AWS_SES_SENDER,
      Template: "TEMPLATE_NAME",
      DefaultTemplateData: '{ "REPLACEMENT_TAG_NAME":"REPLACEMENT_VALUE" }',
      ReplyToAddresses: ["EMAIL_ADDRESS"],
    };

    try {
      const sendPromise = await this.sesClient.send(
        new SendBulkTemplatedEmailCommand(params)
      );
      return sendPromise;
    } catch (err) {
      console.log(err);
    }
  }
}
