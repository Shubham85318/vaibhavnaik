import { HttpException, HttpStatus, Injectable, Logger } from "@nestjs/common";
import { Readable } from "stream";
import {
  S3Client,
  AbortMultipartUploadCommand,
  CompleteMultipartUploadCommand,
  CreateMultipartUploadCommand,
  PutObjectCommand,
  UploadPartCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { awsConfig, s3_buckets } from "src/config";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
require("dotenv").config();

@Injectable()
export class S3ManagerService {
  private s3Client: S3Client;
  private bucket = s3_buckets.AWS_S3_BUCKET;
  private logger: Logger;
  constructor() {
    this.s3Client = new S3Client({
      region: awsConfig.REGION,
      credentials: {
        accessKeyId: awsConfig.ACCESS_KEY,
        secretAccessKey: awsConfig.SECRET_ACCESS_KEY,
      },
    });
    this.logger = new Logger(S3ManagerService.name, { timestamp: true });
  }

  async uploadFileResume(key: string, file): Promise<string> {
    const allowedTypes = ["application/pdf"]; //-> add doc format
    if (!allowedTypes.includes(file.mimetype)) {
      throw new HttpException(
        "Unsupported file format !",
        HttpStatus.UNSUPPORTED_MEDIA_TYPE
      );
    }
    const base64data = new Buffer(file.buffer, "binary");
    const params = {
      Bucket: this.bucket,
      Key: key,
      Body: base64data,
      ContentType: file.mimetype,
    };
    try {
      const command = new PutObjectCommand(params);
      const s3Response = await this.s3Client.send(command);
      return s3Response.ETag;
    } catch (error) {
      console.log(error);
      throw new HttpException(
        `Error uploading resume: ${error.message}`,
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  async downloadFile(key: string) {
    const params = {
      Bucket: this.bucket,
      Key: key,
    };
  }

  async uploadImage(key, file, type) {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/jpg"];
    if (!allowedTypes.includes(file.mimetype)) {
      throw new HttpException(
        "Unsupported file format !",
        HttpStatus.UNSUPPORTED_MEDIA_TYPE
      );
    }
    const base64data = new Buffer(file.buffer, "binary");
    const params = {
      Bucket: this.bucket,
      Key: key,
      Body: base64data,
      ContentType: file.mimetype,
    };
    try {
      const command = new PutObjectCommand(params);
      this.logger.log("file upload started !");
      const s3Response = await this.s3Client.send(command);
      this.logger.log(`upload success for file ${type}`, "ImageFileUpload");
      return s3Response.ETag;
    } catch (error) {
      this.logger.error(error);
      throw new Error(`Error uploading file for ${type} : ${error.message}`);
    }
  }

  async downloadImage(key: string) {
    const params = {
      Bucket: this.bucket,
      Key: key,
    };
    try {
      const response = await this.s3Client.send(new GetObjectCommand(params));
      return response;
    } catch (error) {
      this.logger.error(error);
      throw new Error(`Error downloading file: ${error.message}`);
    }
  }

  async uploadVideo(key: string, file): Promise<string> {
    try {
      const base64data = new Buffer(file.buffer.data, "binary");
      const params = {
        Bucket: this.bucket,
        Key: key,
        Body: base64data,
        ContentType: file.mimetype,
      };
      const command = new PutObjectCommand(params);
      const response = await this.s3Client.send(command);
      this.logger.log(`view360 uploaded for ${key}`);
      return response.ETag;
    } catch (error) {
      this.logger.error(`Error uploading video: ${error.message}`);
      throw new Error(`Error uploading video: ${error.message}`);
    }
  }

  //  multipart upload ===>
  async startMultipartUpload(key: string) {
    const createMultipartUploadParams = {
      Bucket: this.bucket,
      Key: key,
    };
    const createMultipartUploadCommand = new CreateMultipartUploadCommand(
      createMultipartUploadParams
    );
    const { UploadId } = await this.s3Client.send(createMultipartUploadCommand);
    console.log(UploadId);
    return UploadId;
  }

  async uploadPart(
    key: string,
    partNumber: number,
    uploadId: string,
    data: Readable
  ): Promise<string> {
    const uploadPartParams = {
      Bucket: this.bucket,
      Key: key,
      PartNumber: partNumber,
      UploadId: uploadId,
      Body: data,
    };
    const uploadPartCommand = new UploadPartCommand(uploadPartParams);
    const { ETag } = await this.s3Client.send(uploadPartCommand);
    return ETag;
  }

  async completeMultipartUpload(
    key: string,
    uploadId: string,
    parts: { PartNumber: number; ETag: string }[]
  ) {
    const completeMultipartUploadParams = {
      Bucket: this.bucket,
      Key: key,
      UploadId: uploadId,
      MultipartUpload: { Parts: parts },
    };
    const completeMultipartUploadCommand = new CompleteMultipartUploadCommand(
      completeMultipartUploadParams
    );
    await this.s3Client.send(completeMultipartUploadCommand);
  }

  async abortMultipartUpload(
    bucket: string,
    key: string,
    uploadId: string
  ): Promise<void> {
    const abortMultipartUploadParams = {
      Bucket: bucket,
      Key: key,
      UploadId: uploadId,
    };

    const abortMultipartUploadCommand = new AbortMultipartUploadCommand(
      abortMultipartUploadParams
    );

    try {
      await this.s3Client.send(abortMultipartUploadCommand);
    } catch (error) {
      // Handle any errors that occur when aborting the upload
      throw new Error(`Error aborting multipart upload: ${error.message}`);
    }
  }

  async getVideoStreamFromS3(key: string): Promise<Readable> {
    const params = {
      Bucket: this.bucket,
      Key: key,
    };
    try {
      const command = new GetObjectCommand(params);
      const { Body } = await this.s3Client.send(command);
      return Body as Readable;
    } catch (error) {
      throw new Error(`Error fetching video stream from S3: ${error.message}`);
    }
  }

  async generatePresignedURL(key: string): Promise<string> {
    const params = {
      Bucket: this.bucket,
      Key: key,
      Expires: 3600,
    };

    try {
      const command = new GetObjectCommand(params);
      const preSignedUrl = await getSignedUrl(this.s3Client, command);
      return preSignedUrl;
    } catch (error) {
      throw new Error(`Error generating pre-signed URL: ${error.message}`);
    }
  }

  async downloadAvatar(key: string) {
    const params = {
      Bucket: this.bucket,
      Key: key,
    };
    try {
      const response = await this.s3Client.send(new GetObjectCommand(params));
      const docBody = response.Body;
      const convertToString = docBody.transformToString("base64");
      return convertToString;
    } catch (error) {
      this.logger.error(error);
      throw new Error(`Error downloading file: ${error.message}`);
    }
  }
}
