import { Global, Logger, Module } from "@nestjs/common";
import { S3ManagerService } from "./s3.module.service";
import { S3ManagerController } from "./s3.controller";
import { MailService } from "./mail.service";

@Global()
@Module({
  imports: [],
  providers: [S3ManagerService, MailService, Logger],
  controllers: [S3ManagerController],
  exports: [S3ManagerService, MailService],
})
export class SharedModule {}
