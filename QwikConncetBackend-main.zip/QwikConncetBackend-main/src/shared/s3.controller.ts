import { Controller, Get, HttpStatus, Query, Res } from "@nestjs/common";
import { S3ManagerService } from "./s3.module.service";
import { ApiOperation, ApiParam, ApiQuery, ApiTags } from "@nestjs/swagger";
import { Response } from "express";
import { json } from "stream/consumers";
import { extractFilenameFromKey } from "src/utils/extractFileName";
import { Readable } from "stream";

@ApiTags("S3 - S3 Management API's")
@Controller({
  path: "s3-manager",
  version: "1",
})
export class S3ManagerController {
  constructor(private readonly s3ManagerService: S3ManagerService) {}

  @Get("presigned-url")
  @ApiOperation({ description: "Get a Presigned URL for S3 Files" })
  @ApiQuery({
    name: "key",
    type: String,
    description: "Key Of File Location in S3 Bucket",
  })
  async getPresignedUrl(@Query("key") key: string, @Res() res: Response) {
    const response = await this.s3ManagerService.generatePresignedURL(key);
    return res.status(HttpStatus.OK).json(response);
  }

  @Get("/download-avatar")
  @ApiOperation({ description: "download an file by there key name" })
  @ApiQuery({
    name: "key",
    type: String,
    description: "s3 key",
  })
  async downloadAvatar(@Res() res: any, @Query("key") key) {
    console.log("downloaded initiated for this key", key);
    const downloadedDocument = await this.s3ManagerService.downloadAvatar(key);
    return res.status(HttpStatus.OK).json(downloadedDocument);
  }

  @Get("images")
  async getImage(@Query("key") key: string, @Res() res: Response) {
    try {
      const fileStream = await this.s3ManagerService.downloadImage(key);

      res.contentType(fileStream.ContentType);
      res.setHeader("Content-Length", fileStream.ContentLength.toString());
      const filename = extractFilenameFromKey(key);
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${filename}"`
      );

      if (fileStream.Body instanceof Readable) {
        fileStream.Body.pipe(res);
      } else {
        res.status(500).send("Error downloading file from S3");
      }
    } catch (error) {
      res.status(500).send("Error downloading file from S3");
    }
  }
}
