import { config } from "dotenv";
config({ override: true });

export const awsConfig = {
  ACCESS_KEY: process.env.AWS_ACCESS_KEY,
  SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY,
  REGION: process.env.AWS_REGION,
};

export const s3_buckets = { AWS_S3_BUCKET: "qwik-connect" };

export const S3_UPLOADER_QUEUE = "s3_uploader_queue";

export const appPort = process.env.APP_PORT || 3000;

export const defaultRatingParameters = [
  "Concentration",
  "Flexible",
  "Competency",
  "Skills",
  "Aptitude",
];

export const Auth0Config = {
  issuer: process.env.ISSUER_BASE_URL,
  audience: process.env.AUDIENCE,
  clientId: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  redirectUrl: "",
  mng_clientId: process.env.MNG_CLIENT_ID,
  mng_clientSecret: process.env.MNG_CLIENT_SECRET,
};

export const SES_CONFIG = {
  credentials: {
    accessKeyId: process.env.SES_AWS_ACCESS_KEY,
    secretAccessKey: process.env.SES_AWS_SECRET_ACCESS_KEY,
  },
  region: process.env.SES_REGION,
};
export const BaseServiceUrl = process.env.BASE_SERVICE_URL;
export const qwik_connect_domain = process.env.QWIK_CONNECT_DOMAIN;
export const stripeConfig = {
  secretKey : process.env.STRIPE_SECRET_KEY,
  stripe_currency: process.env.STRIPE_APP_CURRENCY,
  webHookSecret : process.env.STRIPE_WEBHOOK_SECRET
}