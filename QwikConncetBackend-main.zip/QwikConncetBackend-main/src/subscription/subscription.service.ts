import { Injectable, Logger } from "@nestjs/common";
import { Stripe } from "stripe";
import { Plans, PlansDocument } from "./schema/plans.schema";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import {
  Subscription,
  SubscriptionDocument,
} from "./schema/subscription.schema";
import { ObjectId } from "mongodb";
import { SubscriptionStatus } from "./enum/suubscription.status";
import { stripeConfig } from "src/config";

@Injectable()
export class SubscriptionService {
  private readonly stripe: Stripe;

  constructor(
    @InjectModel(Plans.name) private readonly planRepo: Model<PlansDocument>,
    @InjectModel(Subscription.name)
    private readonly subscriptionRepo: Model<SubscriptionDocument>,
    private readonly logger: Logger
  ) {
    (this.stripe = new Stripe(stripeConfig.secretKey)),
      {
        //  apiVersion: '2020-08-27', // Specify your Stripe API version
      };
  }

  async createPlan(data): Promise<any> {
    try {
      const stripeProduct = await this.stripe.products.create({
        name: data.planName, //subscription name
        default_price_data: {
          currency: process.env.STRIPE_APP_CURRENCY, //currency from env
          recurring: {
            interval: data.planDuration,
          },
          unit_amount: parseFloat(data.planPrice) * 100,
        },
      });
      console.log(stripeProduct);
      await this.planRepo.create({
        ...data,
        planId: stripeProduct.id,
        priceId: stripeProduct.default_price,
      });
      return stripeProduct;
    } catch (err) {
      throw err;
    }
  }

  async becomeSubscriber(planId, user) {
    //find user that it is subscibed or not

    //find planfrom plan table by plan id

    let customerId;

    if (!user.stripeCostumerId) {
      const customer = await this.stripe.customers.create({
        email: user.email,
      });

      customerId = customer.id;
      const paymentMethod = await this.stripe.paymentMethods.attach(
        "pm_card_visa",
        {
          customer: customerId,
        }
      );
      await this.stripe.customers.update(customerId, {
        invoice_settings: {
          default_payment_method: paymentMethod.id,
        },
      });
    } else customerId = user.stripeCostumerId;

    const stripeSubsciption = await this.stripe.subscriptions.create({
      customer: customerId,
      items: [
        {
          price_data: {
            currency: "",
            product: "plan.productID",
            unit_amount: 200 * 300, //'plan.price * 100',
            recurring: {
              interval: "month",
            },
          },
          metadata: {
            paymentType: "Subscription",
          },
        },
      ],
      payment_settings: {
        payment_method_types: ["card"],
        save_default_payment_method: "on_subscription",
      },
      metadata: {
        paymentType: "Subscription",
      },
      expand: ["latest_invoice.payment_intent"],
    });

    //   const subscription = new Subscription({})craete in trable

    //  const savedUser = await User.findByIdAndUpdate(
    //     req.user._id,
    //     { $push: { subscription: savedSubscription._id },  stripeCostumerId:customerId},
    //     { new: true } //This  option returns the updated document
    //   );   -- update the user subsciption type

    return {
      data: {
        savedSubscription: "savedUser",
        clientSecret:
          " StripeSubscription.latest_invoice.payment_intent.client_secret",
      },
    };
  }

  async stripeSession(plan) {
    try {
      const session = await this.stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [
          {
            price: plan,
            quantity: 1,
          },
        ],
        // expand: ["latest_invoice.payment_intent"],
        success_url: "http://localhost:5173/success",
        cancel_url: "http://localhost:5173/cancel",
      });
      // console.log()
      return session;
    } catch (err) {
      throw err;
    }
  }

  async updateCheckoutSession() {}

  async subscriptionCheckoutSession(plan, customerId) {
    let planId = "price_1ODBbOSBjrwDWUc66nYBZTUj";
    try {
      const session = await this.stripeSession(planId);
      const sessionData = await this.stripe.checkout.sessions.retrieve(
        session.id
      );
      //saving in db
      console.log(session);
      return session;
    } catch (err) {
      throw err;
    }
  }

  // payment success

  async paymentSuccess(req, res) {
    const { sessionId, dbId } = req;
    try {
      const session = await this.stripe.checkout.sessions.retrieve(sessionId);

      if (session.payment_status === "paid") {
        const subscriptionId: any = session.subscription;
        try {
          const subscription: any = await this.stripe.subscriptions.retrieve(
            subscriptionId
          );
          // const user =  get userinfo
          const planId = subscription.plan.id;
          const planType = subscription.plan.amount === 50000 ? "basic" : "pro";
          // const startDate = moment.unix(subscription.current_period_start).format('YYYY-MM-DD');
          // const endDate = moment.unix(subscription.current_period_end).format('YYYY-MM-DD');
          // const durationInSeconds = subscription.current_period_end - subscription.current_period_start;
          // const durationInDays = moment.duration(durationInSeconds, 'seconds').asDays();
          // await admin.database().ref("users").child(user.uid).update({
          //     subscription: {
          // .     subscriptionId: null
          //       sessionId: null,
          //       planId:planId,
          //       planType: planType,
          //       planStartDate: startDate,
          //       planEndDate: endDate,
          //       planDuration: durationInDays
          //     }});
          //
        } catch (err) {
          console.error("Error retrieving subscription:", err);
        }
        return res.json({ message: "Payment successful" });
      } else {
        return res.json({ message: "Payment failed" });
      }
    } catch (err) {
      throw err;
    }
  }

  async subscriptionPaymentSuccess(paymentIntentSucceeded, response) {}

  async subscriptionPaymentFailed(paymentIntentSucceeded, response) {}

  async subscriptionPaymentPending(paymentIntentSucceeded, response) {}

  async subscriptionPaymentCanceled(paymentIntentSucceeded, response) {}

  //web hook for subscription status
  async updateSubscriptionStatus(request, response) {
    const sig = request.headers["stripe-signature"];
    let event;
    try {
      event = this.stripe.webhooks.constructEvent(
        request.body,
        sig,
        "endpointSecret"
      );
    } catch (err) {
      console.log({ err, sig });
      // response.status(400).send(`Webhook Error: ${err.message}`);
      // return;
      throw err;
    }
    console.log(event);
    const paymentIntentSucceeded = event.data.object;
    const paymentType = paymentIntentSucceeded.metadata.paymentType;

    console.log(paymentIntentSucceeded.subscription);

    if (paymentIntentSucceeded.subscription) {
      switch (event.type) {
        case "invoice.payment_succeeded":
          await this.subscriptionPaymentSuccess(
            paymentIntentSucceeded,
            response
          );
          break;
        case "invoice.payment_failed":
          await this.subscriptionPaymentFailed(
            paymentIntentSucceeded,
            response
          );
          break;
        case "invoice.processing":
          await this.subscriptionPaymentPending(
            paymentIntentSucceeded,
            response
          );
          break;
        case "invoice.canceled":
          await this.subscriptionPaymentCanceled(
            paymentIntentSucceeded,
            response
          );
          break;
        default:
          // Handle unknown payment types or do nothing
          break;
      }
    }
  }

  async getPlans() {
    try {
      const plans = await this.planRepo.find();
      return plans;
    } catch (err) {
      throw err;
    }
  }

  async assignSubscription(body: any) {
    try {
      const { user_id, plan_type } = body;
      if (plan_type === "starter") {
        const plan = await this.planRepo.findOne({ planName: plan_type });
        const response = await this.subscriptionRepo.create({
          userId: user_id,
          planId: plan.id,
          status: SubscriptionStatus.ACTIVE,
        });
        return response;
      }
    } catch (error) {
      this.logger.error("Failed to Assign Subscription", error);
    }
  }

  async pollingForSubscriptionId(adminId: any) {
    const result = await this.subscriptionRepo.find({
      adminId:new ObjectId(adminId),
      status: SubscriptionStatus.ACTIVE
    });
    return result;
  }
}
