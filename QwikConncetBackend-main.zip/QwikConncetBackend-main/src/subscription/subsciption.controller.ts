import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  Patch,
  Post,
  Req,
  Res,
} from "@nestjs/common";
import { SubscriptionService } from "./subscription.service";
import { ApiBody, ApiOperation, ApiParam, ApiTags } from "@nestjs/swagger";

@ApiTags("Subscription - subscription's api")
@Controller({
  path: "subscriptions",
  version: "1",
})
export class SubscriptionController {
  constructor(private readonly subscriptionService: SubscriptionService) {}

  @Post("plans")
  @ApiOperation({ description: "api for creating an plan" })
  @ApiBody({ type: Object })
  async createProduct(@Res() res, @Req() req, @Body() body) {
    const product = await this.subscriptionService.createPlan(body); //body.type, body.price
    res.status(HttpStatus.OK).json(product);
  }

  @Post("create-subscription-checkout-session")
  @ApiOperation({ description: "api for becoming an subscriber" })
  @ApiBody({ type: Object })
  async createSubscriptionCheckoutSession(@Res() res, @Body() body) {
    const session = await this.subscriptionService.subscriptionCheckoutSession(
      body.plan,
      body.customerId
    );
    res.status(HttpStatus.OK).json(session);
  }

  @Patch("update-subscription-payment-status")
  @ApiOperation({
    description:
      "this is an webhook api for updating an status subscription status",
  })
  async updatePaymentStatus(@Res() res, @Body() body) {
    //api and webhook for compoleting an payment status
  }

  @Get("plans")
  async getPlans(@Res() res, @Body() body) {
    const plans = await this.subscriptionService.getPlans();
    return res.status(HttpStatus.OK).json(plans);
  }

  @Post("assign-subscriptions")
  @ApiOperation({ description: "Assign subscription to user" })
  @ApiBody({
    type: Object,
  })
  async assignSubscription(@Res() res, @Body() body) {
    await this.subscriptionService.assignSubscription(body);
    return res.status(HttpStatus.OK).send();
  }

  @Get("polling/:subscriptionId")
  @ApiOperation({ description: "Polling subscription for user_id" })
  @ApiParam({
    name: "adminId",
    type: String,
    description: "SubscriptionId of User",
  })
  async pollingForSubscriptionId(
    @Param("adminId") adminId,
    @Res() res
  ) {
    const result = await this.subscriptionService.pollingForSubscriptionId(
      adminId
    );
    return res.status(HttpStatus.OK).json(result);
  }
}
