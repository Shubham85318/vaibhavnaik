import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";
import { FeatureSchema, Feature } from "./feature.schema";

export type PlansDocument = HydratedDocument<Plans>;

@Schema()
export class Plans {
  // type of month and year
  @Prop({ required: true, type: String })
  planDuration: string;

  // premium basic and all
  @Prop({ required: true, type: String })
  planName: string;

  @Prop({ type: String })
  planId: string;

  @Prop({ type: Number })
  planPrice: number;

  @Prop({ type: String })
  currency: string;

  @Prop({ type: String })
  priceId: string;

  @Prop({ required: true, type: FeatureSchema })
  features: Feature;
}

export const PlansSchema = SchemaFactory.createForClass(Plans);
