import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type FeatureDocument = HydratedDocument<Feature>;

@Schema()
export class Feature {
  @Prop({ required: true, type: String })
  totalJobPost: number;

  @Prop({ required: true, type: Number })
  totalInterviews: number;

  @Prop({ required: true, type: Number })
  numberOfInvitation: number;

  @Prop({ required: true, type: Boolean })
  isDownload: boolean;

  @Prop({ required: true, type: Boolean })
  isBranding: boolean;

  @Prop({ required: true, type: String })
  recordingBackup: string;
}

export const FeatureSchema = SchemaFactory.createForClass(Feature);
