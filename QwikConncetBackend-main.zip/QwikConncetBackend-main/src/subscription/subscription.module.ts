import { Logger, Module } from "@nestjs/common";
import { SubscriptionService } from "./subscription.service";
import { SubscriptionController } from "./subsciption.controller";
import { MongooseModule } from "@nestjs/mongoose";
import { Plans, PlansSchema } from "./schema/plans.schema";
import { Subscription, SubscriptionSchema } from "./schema/subscription.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Plans.name, schema: PlansSchema },
      { name: Subscription.name, schema: SubscriptionSchema },
    ]),
  ],
  controllers: [SubscriptionController],
  providers: [SubscriptionService, Logger],
})
export class SubscriptionModule {}
