export enum SubscriptionStatus {
    ACTIVE = "ACTIVE",
    DEACTIVATE = "DEACTIVATE",
  }
  