import { Logger, Module } from "@nestjs/common";
import { IntervieweeService } from "./interviewee.service";
import { IntervieweeController } from "./interviewee.controller";
import { SharedModule } from "src/shared/sharedModule";
import { MongooseModule } from "@nestjs/mongoose";
import { Interviewee, IntervieweeSchema } from "./schemas/interviewee.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Interviewee.name, schema: IntervieweeSchema },
    ]),
    SharedModule,
  ],
  providers: [IntervieweeService, Logger],
  controllers: [IntervieweeController],
  exports: [IntervieweeService],
})
export class IntervieweeModule {}
