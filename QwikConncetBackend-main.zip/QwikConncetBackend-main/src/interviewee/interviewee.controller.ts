import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Put,
  Query,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { IntervieweeService } from "./interviewee.service";
import { FileInterceptor } from "@nestjs/platform-express";
import {
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from "@nestjs/swagger";
import { extractFilenameFromKey } from "src/utils/extractFileName";
import { AuthorizationGuard } from "src/auth/gaurds/auth0.gaurd";
import { ParametersDto } from "./dtos/parameters.dto";
import { JobPostStatQueryDto } from "./dtos/jobPostStatistics.dto";

@ApiTags("Interviewee - Interview AIPs")
@Controller({
  path: "interviewee",
  version: "1",
})
export class IntervieweeController {
  constructor(private readonly intervieweeService: IntervieweeService) {}

  // @UseGuards(AuthorizationGuard)
  @Get()
  @ApiOperation({ description: "Get All Interviewees By AdminId & JobPostId" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @ApiQuery({
    name: "page",
    type: Number,
    description: "Page number",
    required: false,
  })
  @ApiQuery({
    name: "pageSize",
    type: Number,
    description: "Page size",
    required: false,
  })
  async getIntervieweeByJobPostId(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Query("page", new ParseIntPipe()) page: number = 1,
    @Query("pageSize", new ParseIntPipe()) pageSize: number = 10,
    @Res() res
  ) {
    console.log(" --> ", jobPostId, adminId, page, pageSize);
    const result =
      await this.intervieweeService.getIntervieweesByAdminIdAndJobPostId(
        adminId,
        jobPostId,
        page,
        pageSize
      );
    console.log("---->", result);
    return res.status(HttpStatus.OK).json(result);
  }
  @Get("statistics/jobs")
  @ApiOperation({ description: "Get statistic for jobPosts array" })
  @ApiQuery({
    name: "jobPosts",
    type: JobPostStatQueryDto,
    description: "List of job posts",
  })
  async getStatisticsForJobPosts(@Query("jobPosts") jobPosts, @Res() res) {
    const result = await this.intervieweeService.getStatisticsForJobPosts(
      jobPosts
    );
    return res.status(HttpStatus.OK).json(result);
  }

  // @UseGuards(AuthorizationGuard)
  @Get("statistics")
  @ApiOperation({
    description: "Get Interviewee status stats(applied, shortlisted, rejected)",
  })
  @ApiQuery({
    name: "adminId",
    type: String,
    required: false,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    required: false,
    description: "jobPostId",
  })
  async getStatistics(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    const IntervieweeStatisticsData = await this.intervieweeService.getStatistics(adminId, jobPostId);
    return res.status(HttpStatus.OK).json(IntervieweeStatisticsData);
  }

  @Post()
  @ApiOperation({ description: "Onboard Interviewee with Resume" })
  @UseInterceptors(FileInterceptor("resume"))
  async addInterviewee(
    @UploadedFile() resume: Express.Multer.File,
    @Body("json_data") jsonData,
    @Res() res
  ) {
    const data = JSON.parse(jsonData);
    const response = await this.intervieweeService.addInterviewee(data, resume);
    return res.status(HttpStatus.OK).json(response);
  }

  @UseGuards(AuthorizationGuard)
  @Get("resume")
  @ApiOperation({ description: "Get Resume Of Interviewee" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "AdminId",
  })
  async getResume(@Query("key") key: string, @Res() res) {
    const result = await this.intervieweeService.getResume(key);
    console.log("result", result);
    res.setHeader("Content-Type", "application/pdf");
    res.status(HttpStatus.OK);
    res.end(result);
  }

  @UseGuards(AuthorizationGuard)
  @Post("upload-answer")
  @ApiOperation({ description: "Upload Interview Answer Video" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "AdminId",
  })
  @UseInterceptors(FileInterceptor("file"))
  async uploadAnswer(
    @UploadedFile() file: Express.Multer.File,
    @Body("json_data") jsonData: any,
    @Res() res
  ) {
    const data = JSON.parse(jsonData);
    await this.intervieweeService.uploadAnswerVideo(data, file);
    return res.json(`upload-success`);
  }

  @UseGuards(AuthorizationGuard)
  @Post("upload-360")
  @UseInterceptors(FileInterceptor("file"))
  async upload360(
    @UploadedFile() file: Express.Multer.File,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Query("intervieweeId") intervieweeId: string,
    @Res() res
  ) {
    // const data = JSON.parse(jsonData);
    await this.intervieweeService.upload360Video(
      intervieweeId,
      adminId,
      jobPostId,
      file
    );
    return res.json("upload-success");
  }

  @UseGuards(AuthorizationGuard)
  @Get("video/answer")
  async getAnswerVideo(@Query("key") key: string, @Res() res) {
    try {
      console.log("key --> ", key);
      // Retrieve and stream the video
      // const Key = `videos/${adminId}/${jobPostId}/${email}/${questionId}/ans`;
      const videoStream = await this.intervieweeService.getVideo(key);
      // Set the appropriate content type for your video (e.g., "video/mp4")
      res.setHeader("Content-Type", "video/mp4");
      res.setHeader("Accept-Ranges", "bytes");
      // Pipe the video stream to the response
      console.log("ress -> ");
      videoStream.pipe(res);
    } catch (error) {
      // Handle errors, e.g., return an error response
      res.status(500).json({ error: "Error fetching or streaming the video" });
    }
  }

  @UseGuards(AuthorizationGuard)
  @Get("view360")
  async get360Video(@Query("key") Key: string, @Res() res) {
    // Set response headers for content type and content length
    const filename = extractFilenameFromKey(Key);
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    const objectStream = await this.intervieweeService.getVideo(Key);
    objectStream.pipe(res);
  }

  // @UseGuards(AuthorizationGuard)
  @Get(":intervieweeId")
  @ApiOperation({ description: "Get Interviewee Details By Id" })
  @ApiParam({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  async getIntervieweeDetails(
    @Param("intervieweeId") intervieweeId,
    @Res() res
  ) {
    console.log("intervieweeId", intervieweeId);
    const result = await this.intervieweeService.getIntervieweeDetail(
      intervieweeId
    );
    return res.status(HttpStatus.OK).json(result);
  }

  @UseGuards(AuthorizationGuard)
  @Get("question/interview")
  @ApiOperation({ description: "Get Interviewee Questions, one by one" })
  @ApiQuery({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  async getIntervieweeQuestion(
    @Query("intervieweeId") intervieweeId: string,
    @Res() res
  ) {
    const question = await this.intervieweeService.getInterviewQuestion(
      intervieweeId
    );
    return res.status(HttpStatus.OK).json(question);
  }

  @UseGuards(AuthorizationGuard)
  @Post(":interviewee/status")
  @ApiOperation({ description: "update interviewee status for jobPost" })
  @ApiParam({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @ApiQuery({
    name: "status",
    type: String,
    description: "Interviewee Status",
  })
  async updateIntervieweeStatus(
    @Param("intervieweeId") intervieweeId: string,
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Query("status") status: string,
    @Res() res
  ) {
    await this.intervieweeService.updateIntervieweeStatus(
      status,
      adminId,
      jobPostId,
      intervieweeId
    );
    return res.status(HttpStatus.OK).send();
  }

  @UseGuards(AuthorizationGuard)
  @Get("view360/status")
  @ApiOperation({ description: "Get Interviewee 360 upload Status" })
  @ApiQuery({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  async get360UploadStatus(
    @Query("intervieweeId") intervieweeId: string,
    @Res() res
  ) {
    const response = await this.intervieweeService.get360UploadStatus(
      intervieweeId
    );
    return res.status(HttpStatus.OK).json(response);
  }

  @UseGuards(AuthorizationGuard)
  @Get("me")
  @ApiOperation({ description: "Get Interviewee Profile" })
  @ApiParam({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  async getIntervieweeProfile(
    @Param("intervieweeId") intervieweeId: String,
    @Res() res
  ) {
    const IntervieweeProfile =
      await this.intervieweeService.getIntervieweeProfile(intervieweeId);
    return res.status(HttpStatus.OK).json(IntervieweeProfile);
  }

  @Get("parameters")
  @ApiOperation({ description: "Get Interviewee Given Parameters" })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @ApiQuery({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  async getParameters(
    @Query("jobPostId") jobPostId: string,
    @Query("IntervieweeId") intervieweeId: string,
    @Res() res
  ) {
    const parameters = await this.intervieweeService.getParameters(
      jobPostId,
      intervieweeId
    );
    return res.status(HttpStatus.OK).json(parameters);
  }

  // @UseGuards(AuthorizationGuard)
  @Put("parameters")
  @ApiOperation({ description: "Update Parameters" })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  @ApiQuery({
    name: "intervieweeId",
    type: String,
    description: "IntervieweeId",
  })
  @ApiBody({
    type: Object,
    required: true,
  })
  async updateParameters(
    @Query("jobPostId") jobPostId,
    @Query("intervieweeId") intervieweeId,
    @Res() res,
    @Body() body
  ) {
    const response = await this.intervieweeService.updateParameters(
      intervieweeId,
      body
    );
    return res.json(response);
  }
}
