export const JobPostBaseUrl = `http://localhost:4546/admin-apis/v1/job-post`;
