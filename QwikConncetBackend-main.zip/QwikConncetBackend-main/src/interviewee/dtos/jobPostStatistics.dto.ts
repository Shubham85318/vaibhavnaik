import { IsArray, IsString } from "class-validator";

export class JobPostStatQueryDto {
  @IsArray()
  @IsString({ each: true })
  jobPosts: string[];
}
