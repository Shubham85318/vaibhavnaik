import { ApiProperty } from "@nestjs/swagger";

export class ParametersDto {
  @ApiProperty({ name: "Concentration", type: String, required: true })
  Concentration: string;
  @ApiProperty({ name: "Flexible", type: String, required: true })
  Flexible: string;
  @ApiProperty({ name: "Competency", type: String, required: true })
  Competency: string;
  @ApiProperty({ name: "Skills", type: String, required: true })
  Skills: string;
  @ApiProperty({ name: "Aptitude", type: String, required: true })
  Aptitude: string;
}
