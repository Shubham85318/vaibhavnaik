import { ApiProperty } from "@nestjs/swagger";

export class OnBoardIntervieweeDto {
  @ApiProperty({ name: "adminId", type: String, required: true })
  adminId: string;

  @ApiProperty({ name: "jobPostId", type: String, required: true })
  jobPostId: string;

  @ApiProperty({
    name: "fullName",
    type: String,
    required: true,
  })
  fullName: string;

  @ApiProperty({
    name: "email",
    type: String,
    required: true,
  })
  email: string;

  @ApiProperty({ name: "phoneNumber", type: String, required: true })
  phoneNumber: string;

  @ApiProperty({ name: "workExperience", type: String, required: true })
  workExperience: string;

  @ApiProperty({ name: "currentCompany", type: String, required: true })
  currentCompany: string;

  @ApiProperty({ name: "profession", type: String, required: true })
  profession: string;
}
