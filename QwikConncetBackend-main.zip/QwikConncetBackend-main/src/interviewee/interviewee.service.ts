import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  NotFoundException,
  UnauthorizedException,
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Interviewee, IntervieweeDocument } from "./schemas/interviewee.schema";
import { Model } from "mongoose";
import { InterviewStatus } from "./enum/interview.status.enum";
import { ObjectId } from "mongodb";
import { S3ManagerService } from "src/shared/s3.module.service";
import { Readable } from "stream";
import * as http from "../utils/http.util";
import { decrypt, encrypt } from "src/utils/crypto";
import { BaseServiceUrl } from "src/config";

@Injectable()
export class IntervieweeService {
  constructor(
    @InjectModel(Interviewee.name)
    private readonly intervieweeRepo: Model<IntervieweeDocument>,
    private readonly s3ManagerService: S3ManagerService,
    private logger: Logger
  ) { }

  async addInterviewee(body: any, resume) {
    try {
      const { adminId, jobPostId, email } = body;
      this.logger.log(`Saving interviewee with resume`);
      const avatar = await this.getAvatar();
      // create interviewee record for Id
      const interviewee = await this.intervieweeRepo.create({ email: email });
      //  upload resume to s3
      const cv_path = `admins/${adminId}/jobpost/${jobPostId}/interviewees/${interviewee._id}/resume/${resume.originalname}`;
      this.s3ManagerService.uploadFileResume(cv_path, resume);

      // fetch question bank from the JobPost
      const questionBank = await http.get(
        `${BaseServiceUrl}/v1/job-post/question-bank/allot`,
        {
          params: {
            adminId,
            jobPostId,
          },
        }
      );

      // Add alloted questions to interviewee question-bank
      const intervieweeObj = {
        ...body,
        status: InterviewStatus.DRAFTED,
        registration_date: new Date(),
        cv_path: cv_path,
        alloted_questions: questionBank.data.questionBank,
        parameters: questionBank.data.parameters,
        avatar: avatar.key,
      };
      const updatedInterviewee = await this.intervieweeRepo.findByIdAndUpdate(
        interviewee._id,
        intervieweeObj,
        { new: true }
      );
      const code = this.getGuestCode({ adminId, jobPostId, email });
      return { id: interviewee._id, code, updatedInterviewee };
    } catch (error) {
      this.logger.error(`Error get jobPost..`, error);
      throw new HttpException(
        `Error creating Interviewee ... ${body.adminId},${body.jobPostId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getIntervieweesByAdminIdAndJobPostId(
    adminId: string,
    jobPostId: string,
    page: number = 1,
    pageSize: number = 10
  ) {
    try {
      const skip = (page - 1) * pageSize;
      const limit = pageSize;
      console.log(adminId, jobPostId);
      const Interviewees = await this.intervieweeRepo
        .find(
          {
            adminId: adminId,
            jobPostId: jobPostId,
            status: { $ne: "drafted" },
          },
          {
            fullName: 1,
            email: 1,
            status: 1,
            updated_at: 1,
            registration_date: 1,
          }
        )
        .skip(skip)
        .limit(limit);

      console.log("->", Interviewees);
      return Interviewees;
    } catch (error) {
      this.logger.error(`Error Fetching Interviewees Data`, error);
      throw new BadRequestException(error.message);
    }
  }

  async uploadAnswerVideo(body: any, file: Express.Multer.File): Promise<any> {
    try {
      const { adminId, jobPostId, intervieweeId, questionId } = body;
      this.logger.debug(
        `uploading Answer Video for ${adminId}, ${jobPostId}, ${intervieweeId}`
      );

      const key = `admins/${adminId}/jobpost/${jobPostId}/interviewees/${intervieweeId}/videos/${questionId}`;
      this.uploadMultipart(key, file, "answer");

      const result = await this.intervieweeRepo.updateOne(
        {
          _id: intervieweeId,
          alloted_questions: {
            $elemMatch: { _id: questionId }, // Match the questionId
          },
        },
        {
          $set: {
            "alloted_questions.$.ansVideoKey": key, // Update ansVidKey for the matched element
            "alloted_questions.$.isAttempted": true, // Set isAttempted to true for the matched element
          },
        }
      );

      // Fetch the updated interviewee document
      const updatedInterviewee = await this.intervieweeRepo.findOne({
        _id: intervieweeId,
      });

      // Check if all questions are attempted
      const allQuestionsAttempted = updatedInterviewee.alloted_questions.every(
        (question) => question["ansVidKey"] !== undefined
      );

      // If all questions are attempted, update the interview status
      if (allQuestionsAttempted) {
        await this.intervieweeRepo.updateOne(
          { _id: intervieweeId },
          { $set: { status: InterviewStatus.PENDING } }
        );
      }

      return result;
    } catch (error) {
      this.logger.error(`Error upload video...`, error);
      throw new HttpException(
        `Error upload video ...
                ${body.adminId},${body.jobPostId},${body.email}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async upload360Video(
    intervieweeId: any,
    adminId,
    jobPostId,
    file: Express.Multer.File
  ): Promise<any> {
    try {
      // const { email } = body;
      this.logger.log(
        `uploading 360Video for ${adminId}, ${jobPostId}, ${intervieweeId}`
      );
      const key = `admins/${adminId}/jobpost/${jobPostId}/interviewees/${intervieweeId}/videos/${file.originalname}`;
      this.uploadMultipart(key, file, "view360");

      const result = await this.intervieweeRepo.updateOne(
        {
          _id: new ObjectId(intervieweeId),
        },
        {
          $set: { "view360.key": key },
        }
      );
      return result;
    } catch (error) {
      this.logger.error(`Error upload 360video...`, error);
      throw new HttpException(
        `Error upload 360video ...
                ${intervieweeId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getVideo(key: string): Promise<Readable> {
    try {
      const videoStream = await this.s3ManagerService.getVideoStreamFromS3(key);
      return videoStream;
    } catch (error) {
      this.logger.error(`Error streaming file: for key: ${key}`, error);
    }
  }

  async getCandidatesByJobPostId(
    adminId: string,
    jobPostId: string
  ): Promise<any[]> {
    try {
      const candidates = await this.intervieweeRepo
        .find(
          { adminId: adminId, jobPostId: jobPostId },
          { _id: 1, fullName: 1, email: 1, status: 1, updated_at: 1 } // Include only these fields
        )
        .sort({ created_at: -1 }); // Sort in descending order based on 'created_at' field
      if (!candidates) return [];
      return candidates;
    } catch (error) {
      this.logger.error(`Error get candidates...`, error);
      throw new HttpException(
        `Error get candidates ...
                ${adminId},${jobPostId}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getIntervieweeDetail(intervieweeId: string) {
    const interviewee = await this.intervieweeRepo.findOne({
      _id: new ObjectId(intervieweeId),
    });
    return interviewee;
  }

  //upload multipart with s3ManagerService
  async uploadMultipart(key: string, file, type) {
    try {
      const uploadId = await this.s3ManagerService.startMultipartUpload(key);
      console.log("started multipart upload !!");

      // Convert the file buffer to a Readable stream
      const dataStream = Readable.from(file.buffer);

      const parts = [];
      let partNumber = 1;

      console.log("uploading chunks !");

      for await (const chunk of dataStream) {
        const partETag = await this.s3ManagerService.uploadPart(
          key,
          partNumber,
          uploadId,
          chunk
        );
        parts.push({ PartNumber: partNumber, ETag: partETag });
        partNumber++;
      }

      await this.s3ManagerService.completeMultipartUpload(key, uploadId, parts);

      console.log(`Video uploaded successfully of type: ${type},key: ${key}`);
    } catch (error) {
      this.logger.error(`failed to upload video of type: ${type},key: ${key}`);
    }
  }

  async getResume(key: string) {
    // const key = `resume/651137f89cbfd5858dc871a5/651154effdc5ba161f0b15b0/hrushkeshvagga@gmail.com`;
    // const key = `resume/${adminId}/${jobPostId}/${email}`;
    const resume = await this.s3ManagerService.downloadFile(key);
    return resume;
  }

  async getInterviewQuestion(intervieweeId: string) {
    try {
      const interviewee = await this.intervieweeRepo.findById({
        _id: new ObjectId(intervieweeId),
      });

      if (!interviewee) return null;

      const allotedQuestions = interviewee.alloted_questions;
      const currentIndex = allotedQuestions.findIndex(
        (question: any) => !question?.isAttempted
      );

      if (currentIndex === -1) {
        interviewee.status = InterviewStatus.PENDING;
        interviewee.save();
        return null; // No unattempted questions found
      }

      // interviewee.alloted_questions[currentIndex].isAttempted = true;
      // await interviewee.save();

      const nextUnattemptedQuestion = allotedQuestions[currentIndex];

      const totalQuestions = allotedQuestions.length;

      const response = {
        totalQuestions,
        currentIndex,
        nextQuestion: nextUnattemptedQuestion, // Specific object at currentIndex
      };

      return response;
    } catch (error) {
      this.logger.error(`Error In Get Question for Interview ${error}`);
      throw error;
    }
  }

  async updateIntervieweeStatus(
    newStatus: string,
    adminId: string,
    jobPostId: string,
    intervieweeId: string
  ) {
    try {
      await this.intervieweeRepo.findOneAndUpdate(
        { adminId: adminId, jobPostId: jobPostId, _id: intervieweeId },
        { status: newStatus },
        { new: true }
      );
      return;
    } catch (error) {
      this.logger.error(
        `Error Updating Interviewee of intervieweeId: ${intervieweeId}, adminId: ${adminId}, jobPostId: ${jobPostId}`
      );
    }
  }
  async getStatistics(adminId: string = null, jobPostId: string = null) {
    try {

      const subQuery = {}
      if (adminId) subQuery['adminId'] = adminId;
      if (jobPostId) subQuery['jobPostId'] = jobPostId;

      const pending = await this.intervieweeRepo.countDocuments({
        ...subQuery,
        status: InterviewStatus.PENDING,
      });

      const shortlisted = await this.intervieweeRepo.countDocuments({
        ...subQuery,
        status: InterviewStatus.SHORTLISTED,
      });

      const rejected = await this.intervieweeRepo.countDocuments({
        ...subQuery,
        status: InterviewStatus.REJECTED,
      });

      return { pending, shortlisted, rejected };
    } catch (error) {
      this.logger.error(
        `Error Getting Stats Of Interviewee For adminId: ${adminId}, jobPostId: ${jobPostId}`
      );
      this.logger.error(error.message);
      throw new BadRequestException("Failed to get Stats Of Interviewee");
    }
  }

  async get360UploadStatus(intervieweeId: string) {
    const status = await this.intervieweeRepo.findOne({
      _id: new ObjectId(intervieweeId),
    });
    if (!status?.view360?.key) {
      return false;
    }
    return true;
  }
  async getIntervieweeProfile(intervieweeId: String) {
    try {
      const Profile = await this.intervieweeRepo.findOne({
        _id: intervieweeId,
      });
      return Profile;
    } catch (error) {
      this.logger.debug(`Error getting profile of ${intervieweeId}`);
      this.logger.error(error.message);
    }
  }
  async verifyInterviewee(data) {
    const interviewee = await this.intervieweeRepo.findOne({
      email: data.email,
      jobPostId: data.jobPostId,
      adminId: data.adminId,
    });
    if (!interviewee) throw new UnauthorizedException("Interviewee not found");
    return true;
  }

  getGuestCode(data: any): string {
    const exp = new Date();
    exp.setDate(exp.getDate() + 5);
    const code = encrypt({ ...data, exp: exp.getTime() });
    return code;
  }

  async validateCode(data) {
    const code = decrypt(data);
    const now = new Date();
    if (now.getTime() > code.exp) {
      throw new UnauthorizedException("Code Expired");
    }
    await this.verifyInterviewee(code);
    return true;
  }

  async validateInterviewee(adminId, jobPostId, intervieweeId) {
    const interviewee = await this.intervieweeRepo.findOne({
      _id: new ObjectId(intervieweeId),
      jobPostId: jobPostId,
      adminId: adminId,
    });
    if (!interviewee) throw new NotFoundException("Interviewee Not Found");
  }

  async getAvatar() {
    try {
      const response = await http.get(
        `${BaseServiceUrl}/v1/admin/random-avatar`
      );
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }

  async updateParameters(IntervieweeId, data) {
    const response = await this.intervieweeRepo.findByIdAndUpdate(
      {
        _id: new ObjectId(IntervieweeId)
      },
      {
        $set: {
          parameters: data.parameters,
          status: data.status
        }
      }
    );
    return response;
  }

  async getParameters(jobPostId: string, intervieweeId: string) {
    const response = await this.intervieweeRepo.findOne(
      { intervieweeId: new ObjectId(intervieweeId) },
      { parameters: 1 }
    );
    return response;
  }

  async getStatisticsForJobPosts(jobPosts: Array<string>) {
    const result = await Promise.all(
      jobPosts.map(async (job) => {
        const response = await this.getStatistics(null, job);
        return {
          id: job,
          ...response,
        };
      })
    );
    return result;
  }
}
