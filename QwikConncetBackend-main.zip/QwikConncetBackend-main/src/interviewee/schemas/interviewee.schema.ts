import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";
import { InterviewStatus } from "../enum/interview.status.enum";
import { Question } from "./question.schema";

export type IntervieweeDocument = HydratedDocument<Interviewee>;

@Schema({})
export class Interviewee {
  @Prop()
  fullName: string;

  @Prop({ required: true })
  email: string;

  @Prop()
  phoneNumber: string;

  @Prop()
  registration_date: Date;

  @Prop({ enum: InterviewStatus })
  status: string;

  @Prop()
  currentCompany: string;

  @Prop()
  experience: string; //in years

  @Prop()
  profession: string;

  @Prop()
  cv_path: "key of resume";

  @Prop()
  avatar: string;

  @Prop({
    type: {
      key: { type: String },
    },
  })
  view360: {
    key: string;
  };

  @Prop([Question]) //  "will be array of object question attempted will come here" => {questionId,key}
  alloted_questions: Question[];

  @Prop({ type: Object })
  parameters: Object;

  @Prop()
  adminId: string;

  @Prop()
  jobPostId: string;
}

export const IntervieweeSchema = SchemaFactory.createForClass(Interviewee);
