import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument, SchemaTypes } from "mongoose";

export type QuestionDocument = HydratedDocument<Question>;

@Schema({
  timestamps: true,
  _id: false,
})
export class Question {
  @Prop({
    type: SchemaTypes.ObjectId,
    default: () => new mongoose.Types.ObjectId(),
  })
  _id: mongoose.Types.ObjectId;

  @Prop()
  questionNo: number;

  @Prop()
  questionTitle: string;

  @Prop()
  ansVideoKey: string;

  @Prop()
  isMandatory: boolean;

  @Prop()
  retakes: number;

  @Prop()
  thinkingTime: string; //'seconds'

  @Prop()
  timeToAnswer: string; //'seconds'

  @Prop()
  thumbnailUrl: string;

  @Prop({ default: false })
  isAttempted: boolean;
}

export const QuestionSchema = SchemaFactory.createForClass(Question);
