export enum InterviewStatus {
  PENDING = "pending",
  REJECTED = "rejected",
  SHORTLISTED = "shortlisted",
  DRAFTED = "drafted",
}
