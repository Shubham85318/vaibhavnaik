import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import * as express from "express";

import {
  DocumentBuilder,
  SwaggerDocumentOptions,
  SwaggerModule,
} from "@nestjs/swagger";
import { HttpExceptionFilter } from "./utils/ExceptionHndler";
import { VersioningType } from "@nestjs/common";
import { appPort } from "./config";
import { config } from "dotenv";
import rawBodyMiddleware from "./middleware/rawBody.middleware";
config({ override: true });

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableVersioning({
    type: VersioningType.URI,
  });
  app.enableCors();

  // app.use(compression()); // Enable response compression
  const swaggerConfig = new DocumentBuilder()
    .setTitle("Qwick Connect API's")
    .setDescription("Qwik-Connect API's")
    .setVersion("1.0")
    .addBearerAuth({
      description: "JWT Bearer Authorization",
      type: "http",
      scheme: "bearer",
      bearerFormat: "JWT",
    })
    .build();

  const options: SwaggerDocumentOptions = {
    operationIdFactory: (controllerKey: string, methodKey: string) =>
      `${controllerKey}_${methodKey}`,
  };

  const document = SwaggerModule.createDocument(app, swaggerConfig, options);
  SwaggerModule.setup(" ", app, document, {
    customSiteTitle: "qwik-connect API Documentation",
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use(rawBodyMiddleware());
  app.useGlobalFilters(new HttpExceptionFilter());
  await app.listen(appPort);
}
bootstrap();
