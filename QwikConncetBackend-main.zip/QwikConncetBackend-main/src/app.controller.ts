import {
  Body,
  Controller,
  Delete,
  Get,
  HttpException,
  HttpStatus,
  Post,
  Res,
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import {
  sendEmail,
  sendTemplate,
  createTemplate,
  sendBulkMail,
  deleteTemplate,
} from "./utils/sesMailing.utils";
import { otpEmailBody } from "./templates/sendOtp.template";

@Controller()
export class AppController {
  constructor() {}

  @ApiTags("HealthCheck")
  @Get()
  @ApiOperation({ description: "HealthCheck" })
  checkHealth(@Res() res) {
    return res.status(HttpStatus.OK).json("Health Ok!!");
  }

  @ApiTags("Mail- mail's api")
  @Post("send-email")
  async sendEmail(@Res() res) {
    try {
      const re = await sendEmail("vishal.ptr@gmail.com", "arpit");
      return res.status(HttpStatus.OK).json(re);
    } catch (err) {
      throw new HttpException("Not able to send the mail", 400);
    }
  }

  @ApiTags("Mail- mail's api")
  @Post("send-template-email")
  async sendTemplateEmail(@Res() res) {
    try {
      const re = await sendTemplate("avinash.wagh@ayssoftwaresolution.com");
      return res.status(HttpStatus.OK).json(re);
    } catch (err) {
      throw new HttpException("Not able to send the mail", 400);
    }
  }

  @ApiTags("Mail- mail's api")
  @Post("create-template-email")
  async createTemplateEmail(@Res() res) {
    try {
      const re = await createTemplate();
      return res.status(HttpStatus.OK).json(re);
    } catch (err) {
      throw new HttpException("Not able to create an template", 400);
    }
  }

  @ApiTags("Mail- mail's api")
  @ApiOperation({ description: "api for sending bulk mail to users" })
  @Post("send-bulk-template-email")
  async sendBuldEmail(@Res() res, @Body() body) {
    try {
      const re = await sendBulkMail(body.users, body.templateName);
      return res.status(HttpStatus.OK).json(re);
    } catch (err) {
      throw new HttpException("Not able to send an bulk mail", 400);
    }
  }

  @Delete("delete-template")
  async deleteTemplate(@Res() res, @Body() body) {
    try {
      await deleteTemplate(body.templateName);
      return res.status(HttpStatus.OK).json("Template Deleted Successfully!");
    } catch (err) {
      throw err;
    }
  }
}
