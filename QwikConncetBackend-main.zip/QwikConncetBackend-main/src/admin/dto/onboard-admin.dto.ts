import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsPhoneNumber, IsString } from "class-validator";

export class OnboardAdminDto {
  @ApiProperty({
    type: String,
    description: "Auth User Id",
  })
  @IsString()
  _id: string;

  @ApiProperty({
    type: String,
    description: "Full Name of admin",
  })
  @IsString()
  fullName: string;

  @ApiProperty({
    type: String,
    description: "Phone Number with country code(+91)",
  })
  @IsPhoneNumber()
  phone_number: string;

  @ApiProperty({ type: String, required: true, description: "Company Name" })
  @IsString()
  company_name: string;

  @ApiProperty({
    type: String,
    required: true,
    description: "Profession from the array stored",
  })
  @IsString()
  profession: string;

  @ApiProperty({ type: String, required: true, description: "Email Address" })
  @IsEmail()
  email: string;
}
