import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type ContactUsDocument = HydratedDocument<ContactUs>;

@Schema()
export class ContactUs {
  @Prop()
  fullName: string;
  @Prop()
  email: string;
  @Prop()
  phoneNumber: string;
  @Prop()
  message: string;
}
export const ContactUsSchema = SchemaFactory.createForClass(ContactUs);
