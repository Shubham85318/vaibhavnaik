import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { HydratedDocument, SchemaTypes } from "mongoose";

export type AdminDocument = HydratedDocument<Admin>;

@Schema({
  timestamps: true,
  _id: false,
})
export class Admin {
  @Prop({
    type: SchemaTypes.ObjectId,
    default: () => new mongoose.Types.ObjectId(),
  })
  _id: mongoose.Types.ObjectId; //auth id

  @Prop({ unique: true, required: true })
  email: string;

  @Prop({ required: true })
  fullName: string;

  @Prop({ required: true })
  phone_number: string;

  @Prop({ required: true })
  company_name: string;

  @Prop({ required: true })
  profession: string;

  @Prop({ required: true })
  avatar: string; // key for s3

  @Prop()
  draft: string;
}

export const AdminSchema = SchemaFactory.createForClass(Admin);
