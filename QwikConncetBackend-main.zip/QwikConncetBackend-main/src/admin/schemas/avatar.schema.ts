import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type AvatarDocument = HydratedDocument<Avatar>;

@Schema()
export class Avatar {
  @Prop()
  name: string;
  @Prop()
  key: string;
}
export const AvatarSchema = SchemaFactory.createForClass(Avatar);
