import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type TestimonialDocument = HydratedDocument<Testimonial>;

@Schema()
export class Testimonial {
  @Prop({ required: true, type: String })
  name: string;

  @Prop({ required: true, type: String })
  companyName: string;

  @Prop({ required: true })
  location: string;

  @Prop({ required: true, type: String })
  feedback: string;

  @Prop({ required: true, type: String })
  profileKey: string;
}

export const TestimonialSchema = SchemaFactory.createForClass(Testimonial);
