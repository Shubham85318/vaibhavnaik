import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument } from "mongoose";

export type ProfessionsDocument = HydratedDocument<Professions>;

@Schema()
export class Professions {
  @Prop({ required: true, type: String })
  category: string;

  @Prop({ required: true })
  professions: [string];
}

export const ProfessionsSchema = SchemaFactory.createForClass(Professions);
