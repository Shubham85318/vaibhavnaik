import {
  BadRequestException,
  ConflictException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  NotFoundException,
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Admin, AdminDocument } from "./schemas/admin.schema";
import { Professions, ProfessionsDocument } from "./schemas/professions.schema";
import { S3ManagerService } from "src/shared/s3.module.service";
import { Avatar, AvatarDocument } from "./schemas/avatar.schema";
import { getRandomAvatar } from "src/utils/admin.utils";
import { ObjectId } from "mongodb";
import axios from "axios";
import { BaseServiceUrl } from "src/config";
import { ContactUs, ContactUsDocument } from "./schemas/contact-us.schema";
import * as http from "../utils/http.util";
import {
  Testimonial,
  TestimonialDocument,
} from "./schemas/testimonials.schema";

@Injectable()
export class AdminService {
  constructor(
    @InjectModel(Admin.name)
    private readonly adminRepo: Model<AdminDocument>,
    @InjectModel(Professions.name)
    private readonly professionRepo: Model<ProfessionsDocument>,
    @InjectModel(Avatar.name)
    private readonly avatarRepo: Model<AvatarDocument>,
    @InjectModel(ContactUs.name)
    private readonly contactUsRepo: Model<ContactUsDocument>,
    private readonly logger: Logger,
    private readonly s3ManagerService: S3ManagerService,
    @InjectModel(Testimonial.name)
    private readonly testimonialRepo: Model<TestimonialDocument>
  ) {}

  async onBoard(body) {
    try {
      this.logger.log(`onboarding initiated ... ${body.email}`);
      const avatar = await this.getAvatar();
      const onboard = await this.adminRepo.create({
        ...body,
        _id: new ObjectId(body._id),
        avatar: avatar.key,
      });
      this.assignFreeSubscriptionPlan(onboard._id.toString());
      return { onboard, avatar };
    } catch (error) {
      this.logger.error(`onboarding error ... ${error}`, "OnBoardingError");
      if (error.message.includes("duplicate key error")) {
        throw new ConflictException("admin already exist");
      }
      throw new HttpException(
        `Error onboard admin ${body.email}`,
        HttpStatus.BAD_REQUEST
      );
    }
  }

  async getAdminId(email: string) {
    const admin = await this.adminRepo.findOne({ email: email });
    if (!admin) {
      return null;
    }
    return admin._id;
  }

  async getAvatar() {
    const { key, name } = await getRandomAvatar(await this.avatarRepo.find());
    // const fileStream = await this.s3ManagerService.downloadImage(key);
    return { key, name };
  }

  // async getAdminProfile(Id: string) {
  //   try {
  //     this.logger.log(`getData initiated for ${Id}`);
  //     const admin = await this.adminRepo.findOne({ _id: new ObjectId(Id) });
  //     const IntervieweeData = await http.get('http://localhost:4546/v1/interviewee/statistics',
  //     {
  //       params:{adminId:Id}
  //     });
  //     return {admin, IntervieweeData};
  //   } catch (error) {
  //     this.logger.error(
  //       `fetching Admin data error ... ${error}`,
  //       "GetAdminDataError"
  //     );
  //     throw error;
  //   }
  // }

  async getAdminProfile(Id: string, token: string) {
    try {
      this.logger.log(`getData initiated for ${Id}`);
      const admin = await this.adminRepo.findOne({ _id: new ObjectId(Id) });
      const IntervieweeData = await axios.get(
        `${BaseServiceUrl}/v1/interviewee/statistics`,
        {
          headers: {
            Authorization: token,
          },
          params: { 
            adminId: Id 
          }
        }
      );

      return { admin, IntervieweeData: IntervieweeData.data };
    } catch (error) {
      this.logger.error(
        `fetching Admin data error ... ${error}`,
        "GetAdminDataError"
      );
      throw error;
    }
  }

  async getProfessionList() {
    try {
      const professionListData = await this.professionRepo.find();
      return professionListData;
    } catch (error) {
      this.logger.error(`Error retrieve ProfessionsList`, error);
      throw error;
    }
  }

  async addAvatar(file: Express.Multer.File) {
    try {
      const Key = `avatars/${file.originalname}`;
      await this.s3ManagerService.uploadImage(Key, file, "Avatar");
      const Avatar = await this.avatarRepo.create({
        name: file.originalname,
        key: Key,
      });
      console.log(Avatar);
      return;
    } catch (error) {
      this.logger.error(
        `Error Uploading Avatar for ${file.originalname}, error: ${error.message}`
      );
      throw new BadRequestException(error.message);
    }
  }

  async getOneAvatar(key) {
    try {
      const avatar = await this.s3ManagerService.downloadImage(key);
      return avatar;
    } catch (error) {
      this.logger.error(
        `Error Uploading Avatar for ${key}, error: ${error.message}`
      );
      throw new BadRequestException(error.message);
    }
  }
  async updateDetails(adminId, updatedFields) {
    const admin = await this.adminRepo.findById(new ObjectId(adminId));
    if (!admin) {
      throw new HttpException("No Admin Found", 404);
    }
    const updateObject = {};
    for (const key in updatedFields) {
      if (updatedFields.hasOwnProperty(key)) {
        updateObject[key] = updatedFields[key];
      }
    }
    const update_admin_details = await this.adminRepo.findByIdAndUpdate(
      adminId,
      { $set: updateObject },
      { new: true }
    );
    return update_admin_details;
  }

  async checkDraft(adminId: string) {
    try {
      const admin = await this.adminRepo.findById(new ObjectId(adminId));
      if (!admin) {
        throw new NotFoundException(`admin does not exist for ${adminId}`);
      }
      return admin.draft;
    } catch (error) {
      this.logger.error(
        `Error Checking Draft JobPost for ${adminId} : Error ${error}`
      );
      throw error;
    }
  }

  async AddJobPostDraft(adminId: string, jobPostId: string) {
    try {
      const admin = await this.adminRepo.findById(new ObjectId(adminId));
      if (!admin) {
        throw new NotFoundException(`admin does not exist for ${adminId}`);
      }
      await this.adminRepo.findByIdAndUpdate(new ObjectId(adminId), {
        draft: jobPostId,
      });
      return;
    } catch (error) {
      this.logger.error(
        `Error Adding Draft JobPost for ${adminId} : Error ${error}`
      );
      throw error;
    }
  }

  async ClearDraft(adminId: string, jobPostId: string) {
    try {
      const admin = await this.adminRepo.findById(new ObjectId(adminId));
      if (!admin) {
        throw new NotFoundException("admin not found !");
      }
      if (admin.draft === jobPostId) {
        await this.adminRepo.findOneAndUpdate(
          { _id: new ObjectId(adminId) },
          { draft: "" },
          { new: true }
        );
      }
      return;
    } catch (error) {
      this.logger.error(`Error Clearing Draft ${error}`);
      throw error;
    }
  }

  async checkEmail(email: string) {
    const user = await this.adminRepo.findOne({ email: email });
    if (!user) throw new NotFoundException("email does not exist");
    return;
  }

  async validateAdmin(adminId: any) {
    const admin = await this.adminRepo.findOne({ _id: new ObjectId(adminId) });
    if (!admin) throw new NotFoundException("admin does not exist");
  }

  async addContactUs(body: any) {
    await this.contactUsRepo.create(body);
    return;
  }

  //testimonials api
  async createTestimonial(file, data) {
    try {
      const testimonial = await this.testimonialRepo.create(data);
      let Key;
      if (file) {
        //function for uploading an testimonials images
        Key = `testimonials/${testimonial._id}/${file.originalname}`;
        await this.s3ManagerService.uploadImage(Key, file, "Testimonial");
        await this.testimonialRepo.findByIdAndUpdate(testimonial._id, {
          profileKey: Key,
        });
      }
      return testimonial;
    } catch (err) {
      throw err;
    }
  }

  async deleteTestimonial(id) {
    try {
      const objId = new ObjectId(id);
      await this.testimonialRepo.findByIdAndDelete(objId);
      return "testimonial deleted successfully !";
    } catch (err) {
      throw err;
    }
  }

  async updateTestimonial(id, data) {
    try {
      const existingTestimonial = await this.testimonialRepo.findOne(id);

      if (!existingTestimonial) {
        throw new NotFoundException(`Testimonial with ID ${id} not found`);
      }

      const update = await this.testimonialRepo.findOneAndUpdate(id, { data });
      return update;
    } catch (err) {
      throw err;
    }
  }

  async getTestimonial() {
    try {
      const testimonials = this.testimonialRepo.find();
      return testimonials;
    } catch (err) {
      throw err;
    }
  }

  async assignFreeSubscriptionPlan(admin_id) {
    const response = await http.post(
      `${BaseServiceUrl}/v1/subscriptions/assign-subscriptions`,
      {
        user_id: admin_id,
        plan_type: "free",
      }
    );
    return response.data;
  }
}
