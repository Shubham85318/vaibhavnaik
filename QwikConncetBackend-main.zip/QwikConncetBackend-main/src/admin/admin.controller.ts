import {
  Body,
  Controller,
  Delete,
  Get,
  Headers,
  HttpStatus,
  Logger,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Res,
  UploadedFile,
  UseInterceptors,
} from "@nestjs/common";
import { AdminService } from "./admin.service";
import {
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from "@nestjs/swagger";
import { OnboardAdminDto } from "./dto/onboard-admin.dto";
import { FileInterceptor } from "@nestjs/platform-express";
import { Response } from "express";
import { Readable } from "stream";
import { extractFilenameFromKey } from "src/utils/extractFileName";

@ApiTags("Admin - Interviewer AIPs")
@Controller({
  path: "admin",
  version: "1",
})
export class AdminController {
  constructor(
    private readonly adminService: AdminService,
    private readonly logger: Logger
  ) {}

  @Post("on-board")
  @ApiOperation({ description: "OnBoard Admin" })
  @ApiBody({
    type: OnboardAdminDto,
  })
  async onBoard(@Res() res, @Body() body: OnboardAdminDto) {
    const { onboard } = await this.adminService.onBoard(body);
    // const { _, name, fileStream } = avatar;
    res.status(HttpStatus.OK).json(onboard);
    // res.setHeader("Content-Type", fileStream.ContentType);
    // res.setHeader("Content-Length", fileStream.ContentLength.toString());
    // res.setHeader(
    //   "Content-Disposition",
    //   `attachment; filename="${name}"`
    // );
    // if (fileStream.Body instanceof Readable) {
    //   fileStream.Body.pipe(res);
    // } else {
    //   res.status(500).send("Error downloading file from S3");
    // }
  }

  @Get("profile")
  @ApiOperation({ description: "Admin" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  async getAdminProfile(
    @Query("adminId") adminId: string,
    @Res() res,
    @Headers("Authorization") token: string
  ) {
    console.log("adminId", adminId);
    const result = await this.adminService.getAdminProfile(adminId, token);
    return res.status(HttpStatus.OK).json(result);
  }

  @Get("professions")
  @ApiOperation({ description: "Get Profession List" })
  async getProfessionList(@Res() res) {
    const result = await this.adminService.getProfessionList();
    return res.status(HttpStatus.OK).json(result);
  }

  @Put("/:adminId/profile")
  async updateDetails(
    @Res() res,
    @Body() body,
    @Headers() headers,
    @Param("adminId") adminId
  ) {
    try {
      console.log("admminId", adminId, " --- ", body);
      const update_user = await this.adminService.updateDetails(adminId, body);
      return res.status().json(update_user);
    } catch (error) {
      return res.status(HttpStatus.BAD_REQUEST).json(error);
    }
  }

  @Post("avatar")
  @ApiOperation({ description: "Add Profile Pic In Master Data" })
  @ApiBody({
    type: Object,
  })
  @UseInterceptors(FileInterceptor("file"))
  async addProfilePic(@UploadedFile() file: Express.Multer.File, @Res() res) {
    await this.adminService.addAvatar(file);
    return res.status(HttpStatus.OK).send();
  }

  @Get("avatar")
  @ApiOperation({ description: "Get Avatar" })
  async getAvatar(@Res() res: Response, @Query("key") key: string) {
    const fileStream = await this.adminService.getOneAvatar(key);
    res.contentType(fileStream.ContentType);
    res.setHeader("Content-Length", fileStream.ContentLength.toString());
    const filename = extractFilenameFromKey(key);
    res.setHeader("Content-Disposition", `attachment; filename=${filename}`);
    if (fileStream.Body instanceof Readable) {
      fileStream.Body.pipe(res);
    } else {
      res.status(500).send("Error downloading file from S3");
    }
  }

  @Get("random-avatar")
  @ApiOperation({ description: "Get Random Avatar" })
  async getRandomAvatar(@Res() res) {
    const avatar = await this.adminService.getAvatar();
    return res.status(HttpStatus.OK).json(avatar);
  }

  @ApiTags("Admin - Interviewer AIPs")
  @Get("draft-jobpost")
  @ApiOperation({ description: "Check For Draft" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  async CheckDraft(@Query("adminId") adminId: string, @Res() res) {
    const result = await this.adminService.checkDraft(adminId);
    return res.status(HttpStatus.OK).json(result);
  }

  @ApiTags("Admin - Interviewer AIPs")
  @Post("draft-jobpost")
  @ApiOperation({ description: "add JobPost in Draft" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  async setJobPostDraft(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    await this.adminService.AddJobPostDraft(adminId, jobPostId);
    return res.status(HttpStatus.OK).send();
  }

  @ApiTags("Admin - Interviewer AIPs")
  @Post("draft-clear")
  @ApiOperation({ description: "Clear Draft" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  @ApiQuery({
    name: "jobPostId",
    type: String,
    description: "JobPostId",
  })
  async ClearDraft(
    @Query("adminId") adminId: string,
    @Query("jobPostId") jobPostId: string,
    @Res() res
  ) {
    await this.adminService.ClearDraft(adminId, jobPostId);
    return res.status(HttpStatus.OK).send();
  }

  @ApiTags("Admin - Interviewer AIPs")
  @Get("check-email")
  @ApiOperation({ description: "Check If Email Registered Already" })
  @ApiQuery({
    name: "email",
    type: String,
    description: "Email",
  })
  async isEmailExist(@Query("email") email: string, @Res() res) {
    await this.adminService.checkEmail(email);
    return res.status(HttpStatus.OK).send();
  }

  @Get("validate-admin")
  @ApiOperation({ description: "Validate Admin" })
  @ApiQuery({
    name: "adminId",
    type: String,
    description: "AdminId",
  })
  async validateAdmin(@Query("adminId") adminId, @Res() res) {
    await this.adminService.validateAdmin(adminId);
    return res.status(HttpStatus.OK).send("valid");
  }
  @Get(":email")
  @ApiOperation({ description: "get adminId" })
  @ApiParam({
    name: "email",
    type: String,
    description: "Email",
  })
  async getAdminId(@Param("email") email: string, @Res() res) {
    const result = await this.adminService.getAdminId(email);
    return res.status(HttpStatus.OK).json(result);
  }

  @Post("contact-us")
  @ApiOperation({ description: "Post Contact Us" })
  async addContactUs(@Res() res, @Body() body) {
    await this.adminService.addContactUs(body);
    return res.send();
  }
  //testimonials crud

  @ApiTags("Testimonial's api")
  @Post("testimonial")
  @ApiOperation({ description: "Create an testimonial" })
  @ApiBody({
    type: Object,
  })
  @UseInterceptors(FileInterceptor("file"))
  async createTestimonial(
    @UploadedFile() file: Express.Multer.File,
    @Res() res,
    @Body("data") data
  ) {
    const testimonial = await this.adminService.createTestimonial(file, data);
    return res.status(HttpStatus.OK).json(testimonial);
  }

  @ApiTags("Testimonial's api")
  @Get("testimonial")
  @ApiOperation({ description: "get an tetimonial" })
  async getTestimonial(@Body() body, @Res() res) {
    const testimonials = await this.adminService.getTestimonial();
    res.status(HttpStatus.OK).json(testimonials);
  }

  @ApiTags("Testimonial's api")
  @Delete("testimonial/:id")
  @ApiOperation({ description: "delete an testimonial" })
  async deleteTestimonials(@Param("id") id, @Res() res) {
    await this.adminService.deleteTestimonial(id);
    res.status(HttpStatus.OK).send();
  }

  @ApiTags("Testimonial's api")
  @Patch("testimonial/:id")
  @ApiOperation({ description: "update an testimonial" })
  async updateTestimonial(@Param("id") id, @Res() res, @Body() body) {
    await this.adminService.updateTestimonial(id, body);
    res.status(HttpStatus.OK).send();
  }
}
