import { Logger, Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AdminController } from "./admin.controller";
import { AdminService } from "./admin.service";
import { Admin, AdminSchema } from "./schemas/admin.schema";
import { Avatar, AvatarSchema } from "./schemas/avatar.schema";
import { Professions, ProfessionsSchema } from "./schemas/professions.schema";
import { SharedModule } from "src/shared/sharedModule";
import { ContactUs, ContactUsSchema } from "./schemas/contact-us.schema";
import { Testimonial, TestimonialSchema } from "./schemas/testimonials.schema";

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Admin.name, schema: AdminSchema },
      { name: Avatar.name, schema: AvatarSchema },
      { name: Professions.name, schema: ProfessionsSchema },
      { name: ContactUs.name, schema: ContactUsSchema },
      { name: Testimonial.name, schema: TestimonialSchema },
    ]),
    SharedModule,
  ],
  controllers: [AdminController],
  providers: [AdminService, Logger],
  exports: [AdminService],
})
export class AdminModule {}
