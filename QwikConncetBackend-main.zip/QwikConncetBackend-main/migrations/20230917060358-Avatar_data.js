module.exports = {
  async up(db, client) {
    const AvatarsToInsert = [
      {
        name: 'crab.avatar.png',
        key: 'avatars/crab.avatar.png'
      },
      {
        name: 'fish.avatar.png',
        key: 'avatars/fish.avatar.png'
      },
      {
        name: 'seaHorse.avatar.png',
        key: 'avatars/seaHorse.avatar.png'
      },
      {
        name: 'turtle.avatar.png',
        key: 'avatars/turtle.avatar.png'
      },
    ];

    await db.collection("avatars").insertMany(AvatarsToInsert);
  },

  async down(db, client) {
    return ;
  }
};
