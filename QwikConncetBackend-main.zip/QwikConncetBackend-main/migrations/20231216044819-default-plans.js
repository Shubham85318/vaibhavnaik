const { Stripe } = require("stripe");
const v8 = require('v8');
require('dotenv').config();

module.exports = {
  async up(db, client) {
    const defaultPlans = [
      {
        planDuration: "month",
        planName: "essential",
        planPrice: 8,
        features: {
          totalJobPost: 5,
          totalInterviews: 50,
          numberOfInvitation: 6,
          isDownload: true,
          isBranding: true,
          recordingBackup: "60",
        },
      },
      {
        planDuration: "month",
        planName: "professional",
        planPrice: 50,
        features: {
          totalJobPost: 0,
          totalInterviews: 1000,
          numberOfInvitation: 20,
          isDownload: true,
          isBranding: true,
          recordingBackup: "unlimited",
        },
      },
      {
        planDuration: "year",
        planName: "essential",
        planPrice: 14,
        features: {
          totalJobPost: 5,
          totalInterviews: 100,
          numberOfInvitation: 6,
          isDownload: true,
          isBranding: true,
          recordingBackup: "60",
        },
      },
      {
        planDuration: "year",
        planName: "professional",
        planPrice: 75,
        features: {
          totalJobPost: 0,
          totalInterviews: 1000,
          numberOfInvitation: 20,
          isDownload: true,
          isBranding: true,
          recordingBackup: "unlimited",
        },
      },
      {
        planName: "starter",
        planPrice: "free",
        features: {
          totalJobPost: 1,
          totalInterviews: 10,
          numberOfInvitation: 2,
          isDownload: false,
          isBranding: "false",
          recordingBackup: "30",
        },
      },
    ];
    const stripe = new Stripe('sk_test_51OD3HjSBjrwDWUc6ImhzaE2kqZuZS4W36W887T2gEISrDm7PC0GbaISH9VBymnR6qv8H9JxaFEQb54bu3Cswxv0L00x2JGrdYJ');

    try {
      const heapStart = v8.getHeapStatistics(); // Record heap statistics at the start
      const stripePlans = [];
        defaultPlans.map(async (plan) => {
          const planHeapStart = v8.getHeapStatistics(); // Record heap statistics for this plan
          try {
            if (plan.planName !== "starter") {
              const response = await stripe.products.create({
                name: plan.planName,
                default_price_data: {
                  currency: process.env.STRIPE_APP_CURRENCY,
                  recurring: {
                    interval: plan.planDuration,
                  },
                  unit_amount: parseFloat(plan.planPrice) * 100,
                },
              });

              const planHeapEnd = v8.getHeapStatistics(); // Record heap statistics for this plan
              console.log(`Heap memory used for plan ${plan.planName}:`, planHeapEnd.used_heap_size - planHeapStart.used_heap_size, 'bytes');

              stripePlans.push({
                planId: response.id,
                priceId: response.default_price,
                ...plan,
              })
            } else {
              stripePlans.push(plan);
            }
          } catch (err) {
            console.log(`Error processing plan ${plan.planName}:`, err);
            throw err;
          }
        })

      const heapEnd = v8.getHeapStatistics(); // Record heap statistics at the end
      console.log(`Total heap memory used:`, heapEnd.used_heap_size - heapStart.used_heap_size, 'bytes');

      await db.collection("plans").insertMany(stripePlans);
    } catch (err) {
      console.log(err);
      console.log("error to plan creation in stripe ====>");
      throw err;
    }
  },

  async down(db, client) {},
};
