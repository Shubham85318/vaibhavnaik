module.exports = {
  async up(db, client) {
    const professionsToInsert = [
      {
        category: "Accounting and Finance",
        professions: [
          "Accountant",
          "Audit Associate",
          "Bank Manager",
          "Business Analyst",
          "Chief Financial Officer (CFO)",
          "Financial Analyst",
          "Insurance Agent",
          "Tax Consultant",
        ],
      },
      {
        category: "Administrative and Support",
        professions: [
          "Admin Executive",
          "Customer Service Executive",
          "HR Executive",
          "Office Assistant",
          "Receptionist",
          "Secretary",
          "Telecaller",
        ],
      },
      {
        category: "Architecture and Engineering",
        professions: [
          "Architect",
          "Civil Engineer",
          "Electrical Engineer",
          "Mechanical Engineer",
          "Software Engineer",
          "Structural Engineer",
          "Town Planner",
        ],
      },
      {
        category: "Automotive",
        professions: [
          "Automotive Engineer",
          "Car Mechanic",
          "Driver",
          "Sales Executive",
          "Service Advisor",
          "Technician",
        ],
      },
      {
        category: "Banking and Financial Services",
        professions: [
          "Bank Clerk",
          "Banker",
          "Financial Advisor",
          "Investment Banker",
          "Loan Officer",
          "Personal Banker",
        ],
      },
      {
        category: "Business Development and Sales",
        professions: [
          "Business Development Executive",
          "Channel Manager",
          "Key Account Manager",
          "Marketing Executive",
          "Sales Executive",
          "Telesales Executive",
        ],
      },
      {
        category: "Creative and Design",
        professions: [
          "Graphic Designer",
          "Interior Designer",
          "Photographer",
          "Visualiser",
        ],
      },
      {
        category: "Education",
        professions: [
          "Academician",
          "College Lecturer",
          "Education Consultant",
          "Principal",
          "Teacher",
          "Trainer",
        ],
      },
      {
        category: "Engineering",
        professions: [
          "Aerospace Engineer",
          "Chemical Engineer",
          "Civil Engineer",
          "Electrical Engineer",
          "Mechanical Engineer",
          "Petroleum Engineer",
        ],
      },
      {
        category: "Healthcare",
        professions: [
          "Doctor",
          "Dentist",
          "Nurse",
          "Pharmacist",
          "Physiotherapist",
          "Surgeon",
        ],
      },
      {
        category: "IT and Software",
        professions: [
          "Data Scientist",
          "Full Stack Developer",
          "QA Engineer",
          "Software Engineer",
          "UI/UX Designer",
          "Web Developer",
          "DevOps Engineer",
          "Mobile App Developer",
          "Database Administrator",
          "Systems Analyst",
          "Network Engineer",
          "Cloud Architect",
          "Security Analyst",
          "Machine Learning Engineer",
          "Artificial Intelligence Engineer",
          "Game Developer",
        ],
      },
      {
        category: "Legal",
        professions: [
          "Advocate",
          "Lawyer",
          "Legal Executive",
          "Notary Public",
          "Paralegal",
          "Solicitor",
        ],
      },
      {
        category: "Logistics and Supply Chain",
        professions: [
          "Buyer",
          "Freight Forwarder",
          "Inventory Manager",
          "Logistics Executive",
          "Supply Chain Manager",
          "Warehouse Manager",
        ],
      },
      {
        category: "Management",
        professions: [
          "Chief Executive Officer (CEO)",
          "General Manager",
          "Human Resources Manager",
          "Marketing Manager",
          "Operations Manager",
          "Project Manager",
        ],
      },
      {
        category: "Media and Entertainment",
        professions: [
          "Actor",
          "Cameraman",
          "Content Writer",
          "Editor",
          "Journalist",
          "Producer",
        ],
      },
      {
        category: "Sales and Marketing",
        professions: [
          "Business Development Executive",
          "Channel Manager",
          "Key Account Manager",
          "Marketing Executive",
          "Sales Executive",
          "Telesales Executive",
        ],
      },
      {
        category: "Telecom and ITeS",
        professions: [
          "Customer Service Executive",
          "Data Entry Operator",
          "Network Engineer",
          "Software Engineer",
          "Technical Support Executive",
          "Web Developer",
        ],
      },
      {
        category: "Travel and Tourism",
        professions: [
          "Airline Cabin Crew",
          "Air Hostess",
          "Travel Agent",
          "Tour Guide",
          "Travel Writer",
          "Hotelier",
        ],
      },
      {
        category: "Other",
        professions: [
          "Other Services"
        ],
      },
    ];

    await db.collection("professions").insertMany(professionsToInsert);
  },

  async down(db, client) {
    return;
  }
};
